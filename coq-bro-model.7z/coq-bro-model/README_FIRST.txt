
****OVERVIEW****

The authors of the paper "Automatic and Robust Client-Side Protection for 
Cookie-Based Sessions" hereby declare that they are not related to 
Aaron Bohannon and UPenn in any way. The copyright statement by Aaron 
Bohannon was not removed from the source code of the Featherweight Firefox 
model just to avoid any misunderstanding about the intellectual 
property of the starting point of our investigation.

****INTRODUCION****

This folder, consists of libraries for our extended version of the original 
Featherweight Firefox (Extended Featherweight Firefox), our security policy 
to protect web sessions and their proofs.

****COMPILATION****

The Coq source code has been compiled with Coq version
8.3pl5 on Windows 8.

To compile the Coq script code, there are two ways to follow:

USING 'make':
 - on command prompt, enter to the folder having 
  Coq code, e.g., 'coq-bro-model'
 - use the command 'coq_makefile -o Makefile -no-install *.v'
   This will create a file 'Makefile' in the same folder.
 - C:\coq-bro-model>make BrowsrSRS.vo 
    If it complains about the library, use 
    C:\coq-bro-model>make -coqlib C:\Coq\lib BrowsrSRS.vo
   This will compile all the .v files in order automaticall.
   
To execute each individual file, use the following method. 

USING 'coqc':
 - copy the files coqc.exe, coqide.exe and coqtop.exe
   from Coq\bin to the folder, e.g., coq-bro-model.
 - on command prompt, use the command 'coqc' to
   compile individual .v files and create .vo files as below:
   C:\coq-bro-model>coqc -coqlib C:\Coq\lib ACoqFile.v.
 - Compile the files in the following order:
   	GlobalOptions.v
	CaseTactics.v
	GeneralTactics.v
	Tactics.v
	Classes.v
	Datatypes.v
	Collections.v
	Automations.v
	Refs.v
	RefSets.v
	RefPairSets.v
	RefMaps.v
	RefCollections.v
	Reactive.v
	ReactiveSecurity.v
	BrowserIO.v
	UrlMaps.v
	BrowserPolicy.v
	BrowserState.v
	StringMapLemmas.v
	Browser.v
	BrowserProper.v
	BrowserSpec.v
	BrowserRefStructures.v
	BrowserSimilarity.v
	UrlMapLemmas.v
	CookieMapLemmas.v
	RefFreshLemmas.v
	RpsEquivLemmas.v
	BasicLemmas.v
	OpenWinLemmas.v
	LoadInWinLemmas.v
	WinRemoveLemmas.v
	InputTextLemmas.v
	LoadDocLemmas.v
	UpdateCookiesLemmas.v
	ContructNodeTreeLemmas.v
	ExprQueueLemmas.v
	ProcessScriptsLemmas.v 
	ScriptResponseLemmas.v
	XhrRequestEventLemmas.v
	HandleInputEventLemmas.v
	RemoveNodeLemmas.v
	InsertNodeLemmas.v
	SetVarLemmas.v
	StepExprCases.v
	StepExprSimilarityLemmas.v
	StepExprRefFreshLemmas.v
	StepTaskLemmas.v
	BrowserSecurity.v
	BrowserSRS.v
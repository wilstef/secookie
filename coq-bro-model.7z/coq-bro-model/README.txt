================================================================================
        A Formal Proof of Information Security for Featherweight Firefox
================================================================================

:Author: Aaron Bohannon
:Contact: bohannon@cis.upenn.edu
:Date: 13 Apr 2011

Author
------

Thus far, I (Aaron Bohannon) am the sole contributor to the code in this Coq
development.  This development has been built as part of my research in the
Ph.D. program at the University of Pennsylvania, under the direction of my
advisor, Benjamin C. Pierce.  I may be contacted by email at
<bohannon@cis.upenn.edu>.

Overview
--------

The Coq code in this development accomplishes the following:

1. It defines "`reactive systems`_" and "reactive noninterference".
2. It defines a version of the "`Featherweight Firefox`_" web browser model.
3. It defines a security policy based on reactive noninterference for the
   browser model.  The policy addresses confidentiality.
4. It provides a proof that the model satisfies the policy.

.. _reactive systems:
   http://www.cis.upenn.edu/~bohannon/ccs201-bohannon.pdf

.. _Featherweight Firefox:
   http://www.cis.upenn.edu/~bohannon/webapps_2010_bohannon_final.pdf

Building
--------

Running ``make`` should compile the source code.  The code has been built and
tested with Coq version 8.3.

Contents
--------

Key files:

``Reactive.v``
  definition of reactive systems

``ReactiveSecurity.v``
  definition of secure reactive systems

``BrowserIO.v``
  browser input and output events

``BrowserPolicy.v``
  definition a security policy for confidentiality

``BrowserState.v`` and ``Browser.v``
  browser operational semantics

``BrowserSRS.v``
  assertion that the browser model satisfies the policy

Some of the differences between the browser model implemented here and the
Featherweight Firefox model described in our paper at USENIX WebApps 2010 are
listed in the file ``TODO.txt``.

See the file ``CHANGELOG.txt`` for a version history.

License
-------

This Coq development is free software: you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the Free
Software Foundation: either version 3 of the License, or (at your option) any
later version.  See the file COPYING for more information.

If you would like to use this code under a less restrictive license, please
contact me at the email address given above.


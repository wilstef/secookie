 /*The list of sites visited. Ignore cookies set by domains (sites) other than in this list. */
var sitesvisited =
["facebook.com","yahoo.com","","ebay.com","ebay.it","paypal.com","baidu.com","wikipedia.org", "qq.com","taobao.com","live.com",
 "amazon.com","google.com", "twitter.com","linkedin.com","wordpress.com","4shared.com","bitshare.com","blackhatworld.com", "cloob.com","dropbox.com",
 "facenama.com","fanpop.com","github.com","histats.com","facebook.com","imageshack.com","imgur.com","jabong.com","livejournal.com", "mediafire.com",
  "meetup.com","miniclip.com", "moneycontrol.com","mypcbackup.com","odnoklassniki.ru","okcupid.com","pptv.com","rapidgator.net","roblox.com",
  "skyrock.com","statcounter.com","target.com","tmz.com","tradus.com","tumblr.com","vimeo.com", "warriorforum.com","webs.com","wikia.com",
  "xiami.com","deezer.com","cbs.com","sendspace.com","e-hentai.org","kongregate.com","anitube.se","zazzle.com","flashx.tv","businessweek.com",
  "bloombergcurrent.com","dreamstime.com","viadeo.com", "magentocommerce.com","hotfile.com","r2games.com","primewire.ag","zulily.com","zalando.it",
  "ustream.tv","girlsgogames.com","mangafox.me","mangafox.com","screencast.com","instructables.com","lovetime.com","armorgames.com", 
  "grooveshark.com","webhostingtalk.com","adfoc.us","ahrefs.com","stardoll.com","nhl.com","cvs.com","kbb.com","tvguide.com","indiegogo.com",
  "fifa.com","chomikuj.pl","imagetwist.com","vevo.com","gametwist.it", "sitescout.com","gtmetrix.com","privalia.com","admin5.net",
  "depositphotos.com","myvideo.de","nosub.tv","trademe.co.nz","yyets.com","vipzona.info","fatwallet.com","sfimg.com","friendfeed.com","noip.com",
  "newgrounds.com","cityads.ru","wykop.pl","slashdot.org","proboards.com","mundodeportivo.com","topface.com"];
   
function statsIsInVisitedSites (basedom) {
	for (var i=0; i < sitesvisited.length; i++)
		if (basedom == sitesvisited[i])
			return true;
	
	return false;  
}

var logedsites = ["yahoo.com", "facebook.com", "google.com", "unive.it"];

var sredpages = [
"http://www.fifa.com/",
"http://mobile.yahoo.com/;_ylt=AopW4TAEYDqlchLgNYrgLXC.ulI6",
"http://answers.yahoo.com/",
"http://us.lrd.yahoo.com/_ylt=Arh_tfRIet7y4g9iwxKGTAnj1KIX/SIG=11cboai0j/EXP=1392723231/**http%3A//groups.yahoo.com/",
"http://weather.yahoo.com/;_ylt=ApEwp8N40RaXgBFHRA03m.bj1KIX",
"http://finance.yahoo.com/",
"http://sports.yahoo.com/;_ylt=Ak1QCI4W3DJqcmd.cF1FdRiiuYdG;_ylu=X3oDMTBzdWk…hciAxMDA-;_ylg=X3oDMTBxNmg1czNsBGxhbmcDZW4tVVMEcHQDMgR0ZXN0A2dzNTAz;_ylv=3",
"http://news.yahoo.com/;_ylt=AhIr7GWO_AXO.YfBe_E0kn05nYcB;_ylu=X3oDMTBzdWkzZ…hciAxMDA-;_ylg=X3oDMTBxMzhmdm1vBGxhbmcDZW4tVVMEcHQDMgR0ZXN0A2dzMjI5;_ylv=3",
"http://login.yahoo.com/config/login",
"http://www.yahoo.com/",
"http://it.yahoo.com/"];

var nsredpages = [
"http://answers.yahoo.com/",
"http://finance.yahoo.com/"];

var sredsub = [
"http://img.fifa.com/imgml/flags/s/eng.gif",
"http://img.fifa.com/imgml/flags/s/fra.gif",
"http://img.fifa.com/imgml/flags/s/esp.gif",
"http://img.fifa.com/imgml/fifacom2/newsreader/nr.png",
"http://img.fifa.com/imgml/fifacom2/newsreader/playericon.png",
"http://img.fifa.com/imgml/fifacom2/newsreader/relatedicons.gif",
"http://img.fifa.com/imgml/fifacom2/newsreader/nr-sep.png",
"http://img.fifa.com/imgml/fifacom2/newsreader/icons-nr.png",
"http://img.fifa.com/imgml/fifacom2/newsreader/pointer.png",
"http://img.fifa.com/imgml/worldcup/corners.png",
"http://img.fifa.com/imgml/hp/ticker/ticker_bg.png",
"http://img.fifa.com/img/hp/wmc-btn.png",
"http://img.fifa.com/imgml/slider_bg.png",
"http://img.fifa.com/imgml/worldcup/lngc/latestVids/arrows.png",
"http://img.fifa.com/imgml/slider_separator.png",
"http://img.fifa.com/imgml/slider_label_bg.png",
"http://img.fifa.com/imgml/tournament/livepromoBG.gif",
"http://img.fifa.com/imgml/boxes/fifaBoxesSpriteHeader_grid4.gif",
"http://img.fifa.com/imgml/tournament/td_bg.png",
"http://img.fifa.com/imgml/tournament/livepromoFooter.gif",
"http://img.fifa.com/imgml/flags/reflected/m/fra.png",
"http://img.fifa.com/imgml/table/td_odd.png",
"http://img.fifa.com/imgml/flags/flagsp.png",
"http://img.fifa.com/imgml/newscentre/avatarsmallgray.png",
"http://img.fifa.com/imgml/theclub/avatar24x24.png",
"http://img.fifa.com/imgml/newscentre/hys.jpg",
"http://img.fifa.com/imgml/worldcup/lngc/footer_shadow.jpg",
"http://img.fifa.com/imgml/worldcup/separator_03.jpg",
"http://img.fifa.com/imgml/flags/m/egy.gif",
"http://img.fifa.com/imgml/fifacom2/clubdropdown.png",
"http://img.fifa.com/imgml/fifacom2/clubdropdownbg.png",
"http://img.fifa.com/imgml/comments/buttons.gif",
"http://img.fifa.com/imgml/fifacom2/dropdownCK.gif",
"http://img.fifa.com/imgml/animations/loadingSmall.gif",
"http://img.fifa.com/imgml/theclub/bgHeaderBtn.gif",
"http://img.fifa.com/imgml/fifacom2/menu/header_shadow.png",
"http://img.fifa.com/imgml/theclub/h.jpg",
"http://img.fifa.com/imgml/theclub/avatar69x69.png",
"http://img.fifa.com/imgml//theclub/cornice.png",
"http://img.fifa.com/imgml/lev2/arrowmenu.png",
"http://img.fifa.com/imgml/fifacom2/menu/dividers.png",
"http://img.fifa.com/imgml/fifacom2/lev0current.png",
"http://img.fifa.com/imgml/worldcup/boxes/boxShadowFrame.gif",
"http://img.fifa.com/imgml/fifacom2/media_divider.jpg",
"http://img.fifa.com/imgml/fifacom2/fifalogo.png",
"http://img.fifa.com/imgml/fifacom2/bg.png",
"http://img.fifa.com/imgml/fifacom2/menuseparator.png",
"http://img.fifa.com/imgml/fifacom2/searchbg.png",
"http://img.fifa.com/imgml/fifacom2/google_logo.png",
"http://img.fifa.com/imgml/fifacom2/clubdropdownicons.png",
"http://img.fifa.com/imgml/worldcup/mainBg.gif",
"http://img.fifa.com/imgml/fifacom2/chart_icon.png",
"http://img.fifa.com/imgml/fifacom2/fifalogo_foot.png",
"http://img.fifa.com/imgml/fifacom2/corners.png",
"http://img.fifa.com/imgml/boxes/FIFABoxesBody_grid4.gif",
"http://img.fifa.com/imgml/boxes/FIFABoxesSprite_grid4.jpg",
"http://img.fifa.com/imgml/worldcup/boxes/boxShadowFrame.png"];

var nsredsub = [];

var collectedcookies = 
"reg_fb_gate**.facebook.com**/**https%3A%2F%2Fwww.facebook.com%2F%3Fstype%3Dlo%26jlou%3DAfeHieHgmL2oWpy953RcL9dJusmK608we…3D56095%26lh%3DAc8VUTK9LWzmnajh**false**false**true**false**true**false##\
reg_fb_ref**.facebook.com**/**https%3A%2F%2Fwww.facebook.com%2F%3Fstype%3Dlo%26jlou%3DAfeHieHgmL2oWpy953RcL9dJusmK608we…3D56095%26lh%3DAc8VUTK9LWzmnajh**false**false**true**false**true**false##\
c_user**.facebook.com**/**624983951**true**false**false**false**true**false##\
csm**.facebook.com**/**2**false**false**false**false**false**false##\
datr**.facebook.com**/**FM7wUr3QKMmmJKz-aNK0LVGd**false**true**true**false**true**false##\
fr**.facebook.com**/**09VdSWnd0OUGaE5xp.AWX_NpbwqZLm3WSyNj7gux6ezeg.BS8M4d.xX.FLw.AWX7ULMc**false**true**true**false**true**false##\
lu**.facebook.com**/**RAjG4lieoJ8rWkygvC8Qbq_Q**false**true**true**false**true**false##\
s**.facebook.com**/**Aa78B9Y09_bi9V4d.BS8M4d**true**true**false**false**true**false##\
xs**.facebook.com**/**34%3AkvXcUqdMxWC2eg%3A2%3A1391513116%3A13933**true**true**false**false**false**false##\
p**.facebook.com**/**158**false**false**false**false**false**false##\
S**mail.google.com**/mail**gmail=UrtJQca3fyJJw-OxOVXE8Q**true**false**false**false**true**false##\
GAPS**accounts.google.com**/**1:hAQuhFaEC1yEuMSrIXc0lKESmPG0ew:zlzUkY6ipStYOWAx**true**true**false**false**true**false##\
NID**.google.it**/**67=RhYmdl-ZeE1uEcI5J-iXb3s-wgw3c0kMzQhNT0p6YiM_jRjrtpm0MgmxO1CU9Y0aGkAAzRm9oksNuG32NjjFzchGUveWoVqg97lvLAylXZ-ThiFuOlTpYGoqGU4sj7LW**false**true**true**false**true**false##\
SID**.google.it**/**EXPIRED**false**false**true**true**true**false##\
LSID**accounts.google.com**/**EXPIRED**false**false**true**false**true**false##\
HSID**.google.it**/**EXPIRED**false**false**true**true**true**false##\
SSID**.google.it**/**EXPIRED**false**false**true**true**true**false##\
APISID**.google.it**/**EXPIRED**false**false**true**true**true**false##\
SAPISID**.google.it**/**EXPIRED**false**false**true**true**true**false##\
ACCOUNT_CHOOSER**accounts.google.com**/**AFx_qI5fXRXvlj2wN5rROP7cneLBuY3qnJVP7JchJAqR2ODPS6hJla8Hi3DDHGaOHL9ggmSjBed16-gkLh0lzJhTf9qFEuLMUByrg6M41g6cI0Y3W_0LblZ-xswP6sOUUzSjJRJuQCIS**true**true**false**false**true**false##\
GX**.mail.google.com**/mail**EXPIRED**true**false**false**false**false**false##\
GMAIL_RTT**.google.com**/**EXPIRED**true**false**false**false**false**false##\
GMAIL_AT**mail.google.com**/mail**EXPIRED**true**false**false**false**false**false##\
PREF**.google.com**/**ID=7f864532abace0da:FF=0:LD=en:TM=1391513170:LM=1391513170:GM=1:S=AiBQnYAmzjrTtNwk**false**false**true**true**true**false##\
GMAIL_IMP**mail.google.com**/mail**EXPIRED**true**false**false**false**false**false##\
GMAIL_STAT_801c**mail.google.com**/mail**EXPIRED**true**false**false**false**false**false##\
GMAIL_STAT_8cf5**mail.google.com**/mail**EXPIRED**true**false**false**false**false**false##\
GMAIL_STAT_5af0**mail.google.com**/mail**EXPIRED**true**false**false**false**false**false##\
gmailchat**mail.google.com**/mail**EXPIRED**true**false**false**false**false**false##\
GoogleAccountsLocale_session**accounts.google.com**/**en**true**false**false**false**true**false##\
TAID**.google.com**/ads/measurement**EXPIRED**false**false**false**false**false**false##\
LOGIN_INFO**.youtube.com**/**EXPIRED**false**false**false**false**false**false##\
YT_SID**.youtube.com**/**EXPIRED**false**false**true**true**true**false##\
s_vi**.fifa.com**/**[CS]v1|297867480530B616-60000302E0249C2F[CE]**false**false**false**false**false**false##\
fc_lg**secure.fifa.com**/****false**false**false**false**false**false##\
FIFAComClub**.fifa.com**/**un=fubob45&ac=c92a681e-7810-4d77-aeaa-9a8cfd3fd5ab&id=11450340&lc=77C79F55BE9DD5B065566EF8721418A9&ct=ITA&pln=en&m1=&m2=&m3=&n1=&n2=&n3=&nl=0&em=fubob45@gmail.com&wlp=0&wlpn=0&trv=0&trvn=0&yb=1981&fc=8F3A1F07AEF0DD9708D5322AC7CA457A89CBA2FB97036BBE1EE5CB7F96B26D92D27ECE640A62EF4AA8E30700438E0A8496C11106BE1971FB76F892C54140A5AC&pc=6A50454DB9362713C5E869DCCE5FA1202E0141F891C0AE7D96527E1CF0D2AFF6BC4505AAB6A02E1DA1137A151566121BDABA6DED6016FCFF6353180B29B32940&st=45102711&g=f&av=0&pl=0&ag=1&fn=Miranda&ln=Pisano&bd=1981-04-09**false**false**true**false**true**false##\
FIFACom**.fifa.com**/**ap=&bd=1981-04-09&k1=&k2=&k3=&c1=&c2=&c3=&ct=ITA&em=fubob45@gmail.com&fbid=&id=11450340&fn=Miranda&av=0&fb=0&tw=0&pln=en&ln=Pisano&m1=&m2=&m3=&nl=0&un=fubob45&sn=0&twid=&g=f&ac=c92a681e-7810-4d77-aeaa-9a8cfd3fd5ab&ag=1&pl=0&wlp=0&wlpn=0&trv=0&trvn=0&v=&st=45102711&fc=DE874B9C18CD3929B30D020EA2A55173382A88222024C8B9F892047E85AEB3FB67189ACAC929CF4C705DD6BD511E63A1CCBFED297B98301AE89B94AA318B5BF4&pc=6A50454DB9362713C5E869DCCE5FA1202E0141F891C0AE7D96527E1CF0D2AFF6BC4505AAB6A02E1DA1137A151566121BDABA6DED6016FCFF6353180B29B32940**false**false**true**false**true**false##\
B**.yahoo.com**/**0091ol59f1jvp&b=4&d=Nicvo5tpYEKT4Nh0XAmGGizxZaAYGUczIP4VbA--&s=f5&i=iDQe_zJPmZuKivQKNX3B**false**true**false**false**true**true##\
AO**.yahoo.com**/**o=0**false**false**false**false**false**false##\
F**.yahoo.com**/**a=0uoevGcMvSqu0.KuC4ViImeef9iRTlrlZebg.VDjX_jsfn79jgpQBjgVBcZUwZubaSkOo9g-&b=kjaZ**false**true**false**false**true**true##\
Y**.yahoo.com**/**v=1&n=ejk6t2dphrmvq&p=**false**false**true**true**true**false##\
PH**.yahoo.com**/**logout=LnNyYz15biYuaW50bD11cw--&l=en-US**false**false**true**true**true**false##\
FS**.login.yahoo.com**/**v=0&d=c7Td1iDZ7ywlr9U5n27KUQu4EJBsk6bGqvtvxPwgFg--**true**true**false**false**true**false##\
T**.yahoo.com**/**z=0**false**false**false**false**false**false##\
SSL**.yahoo.com**/**%2e**true**false**false**false**false**false##\
X-AC**geo.query.yahoo.com**/v1/public**twP**false**false**false**false**false**false##\
RMBX**.yahoo.com**/**0091ol59f1jvp&b=4&d=Nicvo5tpYEKT4Nh0XAmGGizxZaAYGUczIP4VbA--&s=f5&i=iDQe_zJPmZuKivQKNX3B&t=34**false**true**false**false**true**true##\
ih**ads.yahoo.com**/**;b!!!!$!EAf6!!!!#>[m%g!J:T!!!!!#>[m%E;**false**false**false**false**false**false##\
vuday1**ads.yahoo.com**/**Ajz6%n#C*q!1]R>'iuk#**false**false**true**true**true**false##\
pv1**ads.yahoo.com**/**;b!!!!$!%y<q!!5io!*]C:!J:T!!.EDIF(r><!?5%!'2KV3![`s1!!6n3!1)cl~~~~~~>[m%E>^vGJ~!%l2L!!E)$!+]?j!EAf6!+B<MF(rA=!?5%!'2KV3!ZmB)!!28h!-f`S~~~~~~>[m%g>^vGl~;**false**false**false**false**false**false##\
uid**ads.yahoo.com**/**uid=2db19a4c-8d90-11e3-9d04-10604baeee84&_hmacv=1&_salt=3025258333&_keyid=k1&_hmac=2cd05a9a8f254392e235f92123d0f189b3f2dd3f**false**false**true**true**true**false##\
liday1**ads.yahoo.com**/**1MZqnNg-GU!1]R>#Uw]0**false**false**true**true**true**false##\
answers3**.answers.yahoo.com**/**eyJkIjoibm9uZSIsInYiOiJhMyIsImh0IjoicmVjZW50IiwiaGYiOiJkZWYiLCJjdCI6Im9wZW4iLCJjZiI6ImVuIiwiY3MiOiJuZXciLCJhdCI6ImFuc3dlciJ9**false**false**false**false**false**false##\
itsc**.analytics.yahoo.com**/**TGqG6ZFNaa|ZSwPyjE2|fvis10001393120079=|8M7818M0TT|8M7818M0TT|8M7818M0TT|8|8M7818M0TT|8M7818M0TT**false**false**false**false**false**false##\
bh**ads.yahoo.com**/**;b!!!!#!%xiA!!!!#>[m%h;**false**false**false**false**false**false##\
D**.yahoo.com**/****false**false**false**false**false**false##\
fpc**.www.yahoo.com**/**d=09BQi2dI_.dI34knzMKSzTV7Gqu4.0rK82Dgo_N18UL1MqHKYOszgV…H2mJhKIXCkJ1jrQ94sB.2_P6WTI-&v=2**false**false**true**true**true**false";


var reqpages = [
"http://www.facebook.com/logout.php",
"http://www.facebook.com/",
"http://mail.google.com/mail/",
"http://accounts.google.com/Logout",
"http://accounts.google.com/ServiceLogin",
"http://www.fifa.com/",
"http://secure.fifa.com/theclub/login.htmx",
"http://www.fifa.com/theclub/myprofile/index.htmx",
"http://mobile.yahoo.com/",
"http://screen.yahoo.com/",
"http://answers.yahoo.com/",
"http://us.lrd.yahoo.com/_ylt=Arh_tfRIet7y4g9iwxKGTAnj1KIX/SIG=11cboai0j/EXP=1392723231/**http%3A//groups.yahoo.com/",
"http://weather.yahoo.com/",
"http://finance.yahoo.com/",
"http://finance.yahoo.com/",
"http://sports.yahoo.com/",
"http://news.yahoo.com/",
"http://login.yahoo.com/config/login",
"http://www.yahoo.com/",
"http://it.yahoo.com/",
"http://webmail.dais.unive.it/src/signout.php", ];
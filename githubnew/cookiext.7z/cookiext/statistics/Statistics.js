/* The statics keeps track of some variables for statistics purposes. These variables 
 are retrieved on start-up of the extension. */

/* Global variables - can be accessed in manager to display to user. */
var redsupplinks = []; //list of redirected main-frame request URLs 
var rednotsupplinks = []; //list of failed redirected main-frame request URLs
var redsuppsublinks = []; //list of redirected main-frame request URLs 
var rednotsuppsublinks = []; //list of failed redirected main-frame request URLs

var serverwhitelistpage = []; //list of server white listed (downgraded) (main frame and sub resource) request URLs 
var extwhitelistpage = []; //list of server white listed (downgraded) (main frame and sub resource) request URLs 
var serverwhitelistsub = []; //list of server (by headers or JavaScript) white listed (downgraded) (main frame and sub resource) request URLs 
var extwhitelistsub = []; //list of server white listed (downgraded) (main frame and sub resource) request URLs 

var requestpages = [];   //List of main frame request urls 
var requestsubs = 0;    //Number of sub-resource requests (this is not list of urls, otherwise, the list will be huge, which slow processing)
var logedinsites = [];  //List of sites where the user has loged once. Currently, we are using a list of sites we have created accounts instead, as the logic
						// to detect successful login operation is not enough robust. 

var mycookies = [];	//For statistics - list of cookies received from server, with cookie flags and extension related flags

var minimumLength = 10;
var randomnessThreshold = 0.04;

function Statistics(minLength, randThreshold) {
	//localminLength = minLenght;
	//localrandThreshold = randThreshold;
	
  	//Populates the list of 'redsupplinks' from local storage, separated by ";".
	chrome.storage.local.get("redsupplinks", function (items) { // /items: Object with items in their key-value mappings.
	if(items["redsupplinks"]) {
		redsupplinks = items["redsupplinks"].split("**"); 
	}
	});

	//Populates the list of 'rednotsuppLinks' from local storage, separated by ";".
	chrome.storage.local.get("rednotsupplinks", function (items) { // /items: Object with items in their key-value mappings.
	if(items["rednotsupplinks"]) {
		rednotsupplinks = items["rednotsupplinks"].split("**");  
	}
	});
		
	//Populates the list of 'redsuppsubLinks' from local storage, separated by ";".
	chrome.storage.local.get("redsuppsublinks", function (items) { // /items: Object with items in their key-value mappings.
	if(items["redsuppsublinks"]) {
		redsuppsublinks = items["redsuppsublinks"].split("**"); 
	}
	});

	//Populates the list of 'rednotsuppsubLinks' from local storage, separated by ";".
	chrome.storage.local.get("rednotsuppsublinks", function (items) { // /items: Object with items in their key-value mappings.
	if(items["rednotsuppsublinks"]) {
		rednotsuppsublinks = items["rednotsuppsublinks"].split("**");  
	}
	});
	
	//Populates the list of 'serverwhitelistpage' from local storage, separated by ";".
	chrome.storage.local.get("serverwhitelistpage", function (items) { // /items: Object with items in their key-value mappings.
	if(items["serverwhitelistpage"]) {
		serverwhitelistpage = items["serverwhitelistpage"].split("**"); 
	}
	});	
	
	
	//Populates the list of 'extwhitelistpage' from local storage, separated by ";".
	chrome.storage.local.get("extwhitelistpage", function (items) { // /items: Object with items in their key-value mappings.
	if(items["extwhitelistpage"]) {
		extwhitelistpage = items["extwhitelistpage"].split("**"); 
	}
	});	
	
	//Populates the list of 'serverwhitelistsub' from local storage, separated by ";".
	chrome.storage.local.get("serverwhitelistsub", function (items) { // /items: Object with items in their key-value mappings.
	if(items["serverwhitelistsub"]) {
		serverwhitelistsub = items["serverwhitelistsub"].split("**"); 
	}
	});	
	
	
	//Populates the list of 'extwhitelistsub' from local storage, separated by ";".
	chrome.storage.local.get("extwhitelistsub", function (items) { // /items: Object with items in their key-value mappings.
	if(items["extwhitelistsub"]) {
		extwhitelistsub = items["extwhitelistsub"].split("**"); 
	}
	});	
	
	
	//Populates the list of 'mycookies' from local storage, separated by ";".
	chrome.storage.local.get("mycookies", function (items) { // /items: Object with items in their key-value mappings.
	if(items["mycookies"]) {
		mycookies = items["mycookies"].split(";"); 
	}
	});	
	
	//Populates the list of 'requestpages' from local storage, separated by ";".
	chrome.storage.local.get("requestpages", function (items) { // /items: Object with items in their key-value mappings.
	if(items["requestpages"]) {
		requestpages = items["requestpages"].split("**"); 
	}
	});
	
	
	//Populates the 'requestsubs' from local storage.
	chrome.storage.local.get("requestsubs", function (items) { // /items: Object with items in their key-value mappings.
	if(items["requestsubs"]) {
		requestsubs = parseInt( items["requestsubs"]);  //parseInt()
	}
	}); 	
	
	//Populates the 'logedinsites' from local storage.
	chrome.storage.local.get("logedinsites", function (items) { // /items: Object with items in their key-value mappings.
	if(items["logedinsites"]) {
		logedinsites = items["logedinsites"].split(";");
	}
	}); 
	
}

/*Add the site (its base domain) to the list of loged sites. The parameter
is the base domain object. */
function statsAddLogedInSites (basedomain) {
	logedinsites = addStrList (logedinsites, basedomain.toString());
			
	var sitesStr;
	if (logedinsites.length < 1)
		return;
	else 
		sitesStr = logedinsites.join(";"); //Joins all the elements of array separated by ";"
	chrome.storage.local.set({"logedinsites": sitesStr}); //Updates the local storage. 
	
	//console.log ("Loged sites: " + logedinsites);
	return;
}

/*Checks if the site (its base domain) is in the list of loged sites. The parameter
is the base domain object. */
function isSiteInLogedIn (basedomain) {
	
	if (!logedinsites.length > 0)
		return false;
	for (i=0; i<logedinsites.length; i++)
		if (basedomain.toString() == logedinsites[i])
			return true;
	
	return false;
}


/*List of sites (base domains) visited. */
function getSitesVisited () {
	var sitesvisted = [];
	for ( i=0; i < requestpages.length; i++) {
		var basedomain = getUrlBaseDomain(URI(requestpages[i]));
		sitesvisted = addStrList(sitesvisted, basedomain);		
	}
	
	return sitesvisted;
}

/*Checks if a site (base domain) is in the list of main page redirection not supported list*/
function isSiteInNotRedSuppPage (basedomain) {
	if (!rednotsupplinks.length > 0)
		return false;
	for (i=0; i < rednotsupplinks.length; i++){
		if (basedomain === getUrlBaseDomain(URI(rednotsupplinks[i])))
			return true;	
	}
	
	return false;
}

/*Checks if a site (base domain) is in the list of main page redirection supported list (at least
a request redirection was supported). */
function isSiteInRedSuppPage (basedomain) {
	if (!redsupplinks.length > 0)
		return false;
	for (i=0; i < redsupplinks.length; i++){
		if (basedomain === getUrlBaseDomain(URI(redsupplinks[i])))
			return true;	
	}
	
	return false;
}

/*Gets the list of sites (base domains) fully supporting https (at least for the main
page requests navigated by the user or for main page requests as result of user-navigated
page requests. A site is considered fully supported (it was partially supported, but 
CookiExt made if fully supported), if there exists a successful redirect to https and 
the site is not in un-successful redirect list. Currently, we are considering only main
frame (page) requests. */
function getFullHttpsSuppSites () {
	var fullhttpssuppsites = [];
	var sitesvisted = getSitesVisited();
	for (var i=0; i < sitesvisted.length; i++) {
		if (!isSiteInNotRedSuppPage (sitesvisted[i]) && isSiteInRedSuppPage(sitesvisted[i]) )
			fullhttpssuppsites.push(sitesvisted[i]);
	}
	
	return fullhttpssuppsites;
}

function updateStatistics (response, source){
	if (response.tabId == -1)
		return;
		
	//Change the url to http if it is https and remove query/fragment parts
	var url = removeQueryString(URI(response.url.replace('https', 'http'))).toString();
	var reqTabPageRelated = false;  // Is sub request related to the page in tab (and is not request to third party resources like ads etc);
	
	if (source === 'ADD_REQUEST_LOGIN') {	    
		/*An AJAX request can be a login, and as the login detection takes time (asynchronous) and the corresponding page
		request may arrive in that time, which will be ignored, just to approximate, the AJAX login request is added to
		page requests above. An AJAX request if it is not login, is otherwise, counted as sub-resource. */
		if (response.type === PAGE || response.type === AJAX)
			requestpages = addRequestPages (requestpages, url);
		else { 
			requestsubs++;
			chrome.storage.local.set({"requestsubs": requestsubs}); //Updates the local storage.
		}
	}
	
	
		
	/*For statistics, only main page requests or requests related to the url in tab are considered. Third party requests for resources are
	not considered. */
	chrome.tabs.get(response.tabId, function(tab) {
		if (!tab)
			return;
		
		if (response.type == PAGE || getUrlBaseDomain(URI(url)) === getUrlBaseDomain(URI(tab.url))) 
			reqTabPageRelated = true;
			
		    var isreqinlist = statsIsInVisitedSites(getUrlBaseDomain(URI(url))); //Use this if a list of sites where user have account is available
			var issitelogedin = isSiteInLogedIn(getUrlBaseDomain(URI(url)).toString()); //Use this for testing by users or when login checker is robust
			
			/*A request is counted in statistics only if it is either a login or the site has already loged-in. Currently, 
			as the login checking logic is not robust and a login operation may skip, so we check the destination site in the 
			list of sites where we have created personal account. Replace 'isreqinlist' with 'issitelogedin' when login checking
			is robust enough or the extension is being test by set of users on sites of their choice. */
			if (source === 'ADD_REQUEST' && issitelogedin) { 
				if (response.type === PAGE)
					requestpages = addRequestPages (requestpages, url);
				else if (reqTabPageRelated) {
						requestsubs++;
						chrome.storage.local.set({"requestsubs": requestsubs}); //Updates the local storage. 
				}
			} else if (source === 'SERVER_REDIRECT') {
				if (response.type === PAGE) {
					serverwhitelistpage = addSerWhiteListPage(serverwhitelistpage, url); //Add the page url to server white-list 
					updateRedirectPages (url, false);	// Delete url from supported list - add to non-supported list.
				}
				else if (reqTabPageRelated) {
					serverwhitelistsub = addSerWhiteListSub(serverwhitelistsub, url);    //Add the sub-resource url to server white-list 
					updateRedirectSub (url, false);		// Delete url from supported list - add to non-supported list.
				}	
			} else if (source === 'SSL_RELATED_ERROR') {
				if (response.type === PAGE) {
					extwhitelistpage = addExtWhiteListPage(extwhitelistpage, url);   //Add the page url to extension white-list 
					updateRedirectPages (url, false); 	 // Delete url from supported list - add to non-supported list.		
				}
				else if (reqTabPageRelated) {
					extwhitelistsub = addExtWhiteListSub(extwhitelistsub, url);	    //Add the sub-resource url to extension white-list 
					updateRedirectSub (url, false);		// Delete url from supported list - add to non-supported list.
				}				
			} else if (source === 'REQUEST_UPDATED') {
				if (response.type === PAGE)
					updateRedirectPages (url, true);  // Add url to supported list - delete from non-supported list.
				else if (reqTabPageRelated)
					updateRedirectSub (url, true);  	// Add url to supported list - delete from non-supported list.	
			}
	});
	return;
}

/*Updated 'mycookies' in memory and storage. */
function statsUdpateCookies (cookie, response) {
	// Dont replace the cookie if it is to be removed
	if (response.tabId == -1 || cookie.value == "deleted" || cookie.value == "" || cookie.value == "EXPIRED")
		return;		
		
	//cookie.value.replace("*", '$');
	//cookie.name.replace("*", '$');
	
	var reqTabPageRelated = false;
	
	//cookie.name(replace('*', ';')); //A cookie name may contain letter '*', which is already used as item separator. 
	
	/*For statistics, only cookie set through main page responses or responses related to the url in tab are considered.
	Cookies set by third party responses are not considered. */
//	chrome.tabs.get(response.tabId, function(tab) {
//		if (!tab)
//			return;
//		if (response.type === PAGE || getUrlBaseDomain(URI(response.url)) === getUrlBaseDomain(URI(tab.url))) 
			reqTabPageRelated = true;
			
			if (reqTabPageRelated) {				
				var cookiestr = cookie.name + "**" + cookie.domain + "**" + cookie.path
					+ "**" + cookie.value + "**" + cookie.secure + "**" + cookie.httponly    
					+ "**" + cookie.securesetext + "**" + cookie.httpsetext + "**" + cookie.session + "**" + cookie.reverted;
					
				if (mycookies.length > 0) {
					var found = false;
					for (var i = 0; i < mycookies.length && !found; i++) {
						var cookieObj = parseCookieStr(mycookies[i]);						
						found = cookieNameDomMatch(cookieObj, cookie);	
						
					/* If a cookie with same name and domain already exists in 'mycookies' store, check for path pattern matching.
					If the cookie path pattern match the existing one, replace it, except the path. If the cookie with path '/'
					is in the store, and a new cookie with path '/src' arrives, the earlies one is replaced except the path. 
					The shorter one has higher precedence. FIXME: This needs to make aligned with the corresponding HTTP 
					management standard, however, for statistics purposes, this does not make any significant difference. */
						if (found) {
							if (pathPattMatch (cookieObj.path, cookie.path))
								cookiestr = cookie.name + "**" + cookie.domain + "**" + cookieObj.path
								+ "**" + cookie.value + "**" + cookie.secure + "**" + cookie.httponly    
								+ "**" + cookie.securesetext + "**" + cookie.httpsetext + "**" + cookie.session + "**" + cookie.reverted;
							delete mycookies[i];
							mycookies[i] = cookiestr;			
						}		
					}
					if (!found)
						mycookies = mycookies.concat([cookiestr]);
				} else 
					mycookies = [cookiestr];
		
				//Updates 'mycookies' in the local storage.
				if (mycookies.length > 1) // If there are more than one element, join them by ";".
					var mycookiesStr = mycookies.join(";"); //Joins all the elements of array separated by ";"
				chrome.storage.local.set({"mycookies": mycookiesStr});
			}
//		});
		
	return;
}


 
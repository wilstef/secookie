
/* Method implementing an heuristic based on the index of coincidence to choose if a given cookie is used
for session management. */
function statIsSessCookie(cookie) {
	/* Test the cookie name against strings which are known to be commonly used in name
	for session or authentication cookies. */
	var patterns = [/.*sess.*/i, /.*sid.*/i, /.*uid.*/i, /.*user.*/i, /.*auth.*/i, /.*key.*/i];
	for (var i = 0; i < patterns.length; i++)
		if (patterns[i].test(cookie.name))
			return true;

	var value = cookie.value;
	try {
		value = decodeURIComponent(cookie.value);
	} catch (err) {}
		
	/* Too short to be a session cookie. */
	if (value.length < minimumLength)
		return false;
	/* Count character occurrences. */
	var freqs = new Array(256);
	for(i = 0; i < 256; i++)
		freqs[i] = 0;
	for(i = 0; i < value.length; i++)
		freqs[value.charCodeAt(i)]++;
	/* Check if the index of coincidence is below the given threshold. */
	var sum = 0;
	for(i = 0; i < 256; i++)
		sum += freqs[i] * (freqs[i] - 1);	
	return  (sum / (value.length * (value.length - 1))) < randomnessThreshold;
};

/*Update, in memory and storage, the list of main_frame requests sent by browser. */
function addRequestPages(requestpages, url){ 
  var requestpages = addUrlList(requestpages, url);  
  var requestpagesStr = requestpages.join("**"); //Joins all the elements of array separated by ";"
  chrome.storage.local.set({"requestpages": requestpagesStr}); //Updates the local storage. 
 
 return requestpages;
}

 //Update page redirect (non-)supported lists 				    
function updateRedirectPages (url, addordel){
	updateSuppNotLinks(url, addordel);
	return;
}

//Update sub-resource redirect (non-)supported lists 	
function updateRedirectSub (url, addordel){
	var subRed = updateSuppNotSubLinks({redsuppsublinks: redsuppsublinks, rednotsuppsublinks: rednotsuppsublinks, url: url}, addordel);
	redsuppsublinks = subRed.redsuppsublinks;
	rednotsuppsublinks = subRed.rednotsuppsublinks;
}
	   
//Updates the lists of redirection supported ('redsuppLinks') and non-supported ('rednotsuppLinks') links
function updateSuppNotLinks(url, addordel){ 
    
    //Updates 'rednotsupplinks' list
	if(!addordel) {  //url is not supported. Add to 'rednotsupplinks' list
		if (rednotsupplinks.length > 0) {       
			var j = 0;
			var found = false;
			while(j < rednotsupplinks.length) {
				if( rednotsupplinks[j] == url){
					found = true;
					break;
				}
			j++;
			}
			if(!found) //Not in list and add it
				rednotsupplinks = rednotsupplinks.concat([url]);		   
		} else 		   
			rednotsupplinks = [url];
			
		//Updates 'rednotsupplinks' in the local storage.
		var rednotsupplinksStr = rednotsupplinks.join("**"); //Joins all the elements of array separated by ";"
		chrome.storage.local.set({"rednotsupplinks": rednotsupplinksStr}); //Updates the local storage.
	}
	 
	if (redsupplinks.length > 0) {
		found = false;
		var i = 0;
		while(i < redsupplinks.length && !found) {    //Finds the index of the entry
			if( redsupplinks[i] == url)
				found = true;
			i++;
		}
		if(!found && addordel) //Not in list, add it
			redsupplinks = redsupplinks.concat([url]);
		if(found && !addordel) //In list, delete it
			redsupplinks.splice(i-1,1);		   
	} else if(addordel)			   
		redsupplinks = [url];
	
	//Updates 'redsupplinks' in the local storage.
	var redsupplinksStr = redsupplinks.join("**"); // /join all the elements of array separated by ";"
	chrome.storage.local.set({"redsupplinks": redsupplinksStr}); // /updates the local storage.
	
	return; // {redsupplinks:redsupplinks, rednotsupplinks: rednotsupplinks};
}



//Updates the lists of redirection supported ('redsuppLinks') and non-supported ('rednotsuppLinks') links
function updateSuppNotSubLinks(request, addordel){ 
    var redsuppsublinks = request.redsuppsublinks;
	var rednotsuppsublinks = request.rednotsuppsublinks;
	var url = request.url; //URL without query part

    //Updates 'rednotsuppsublinks' list
	if(!addordel) {  //url is not supported. Add to 'rednotsuppsublinks' list
		if (rednotsuppsublinks.length > 0) {       
			var j = 0;
			var found = false;
			while(j < rednotsuppsublinks.length) {
				if( rednotsuppsublinks[j] == url){
					found = true;
					break;
				}
			j++;
			}
			if(!found) //Not in list and add it
				rednotsuppsublinks = rednotsuppsublinks.concat([url]);		   
		} else 		   
			rednotsuppsublinks = [url];
			
		//Updates 'rednotsuppsublinks' in the local storage.
		var rednotsuppsublinksStr = rednotsuppsublinks.join("**"); //Joins all the elements of array separated by ";"
		chrome.storage.local.set({"rednotsuppsublinks": rednotsuppsublinksStr}); //Updates the local storage.
	}
	 
	if (redsuppsublinks.length > 0) {
		found = false;
		var i = 0;
		while(i < redsuppsublinks.length) {    //Finds the index of the entry
			if( redsuppsublinks[i] == url){
				found = true;
				break;
			}
			i++;
		}
		if(!found && addordel) //Not in list, add it
			redsuppsublinks = redsuppsublinks.concat([url]);
		if(found && !addordel) //In list, delete it
			redsuppsublinks.splice(i-1,1);		   
	} else if(addordel)			   
		redsuppsublinks = [url];
	
	//Updates 'redsuppsublinks' in the local storage.
	var redsuppsublinksStr = redsuppsublinks.join("**"); // /join all the elements of array separated by ";"
	chrome.storage.local.set({"redsuppsublinks": redsuppsublinksStr}); // /updates the local storage.
	
	return {redsuppsublinks:redsuppsublinks, rednotsuppsublinks: rednotsuppsublinks};
}


/*Update, in memory and storage, the extension white-list. */
function addExtWhiteListPage(whitlist, redurl){ 
  var extwhitelistpage = addUrlList(whitlist, redurl);  
  var extwhitelistpageStr = extwhitelistpage.join("**"); //Joins all the elements of array separated by ";"
  chrome.storage.local.set({"extwhitelistpage": extwhitelistpageStr}); //Updates the local storage. 
 
 return extwhitelistpage;
}

/*Update, in memory and storage, the extension white-list. */
function addExtWhiteListSub(whitlist, redurl){ 
  var extwhitelistsub = addUrlList(whitlist, redurl);  
  var extwhitelistsubStr = extwhitelistsub.join("**"); //Joins all the elements of array separated by ";"
  chrome.storage.local.set({"extwhitelistsub": extwhitelistsubStr}); //Updates the local storage. 
 
 return extwhitelistsub;
}

/*Update, in memory and storage, the server white-list. */
function addSerWhiteListSub (whitlist, redurl){ 
  var serverwhitelistsub = addUrlList(whitlist, redurl);  
  var serverwhitelistsubStr = serverwhitelistsub.join("**"); //Joins all the elements of array separated by ";"
  chrome.storage.local.set({"serverwhitelistsub": serverwhitelistsubStr}); //Updates the local storage. 
 
 return serverwhitelistsub;
}

/*Update, in memory and storage, the server white-list. */
function addSerWhiteListPage(whitlist, redurl){ 
  var serverwhitelistpage = addUrlList(whitlist, redurl);  
  var serverwhitelistpageStr = serverwhitelistpage.join("**"); //Joins all the elements of array separated by ";"
  chrome.storage.local.set({"serverwhitelistpage": serverwhitelistpageStr}); //Updates the local storage. 
 
 return serverwhitelistpage;
}

function addStrList(list, str){ 	
	
	//updates the str-list array for immediate use
	if (list.length > 0) {
		var j = 0;
		var found = false;
		while ( j < list.length) {
			if(list[j] == str)
				found = true; 
			j++;
		}
		if (!found){
			list = list.concat([str]);
		}
	} else			   
		list = [str];	
	
    return list;	
}

//Updates the 'urllist' array - used to update 'whitelist' and 'serverwhitelist'
function addUrlList(urllist, url){ 
	var whiteurl = url; 
	
	//updates the url-list array for immediate use
	if (urllist.length > 0) {
		var j = 0;
		var found = false;
		while ( j < urllist.length) {
			//var patt = new RegExp(urllist[j] + "*",  "i");  // pattern: /url*/i - URLs without query part
			if(urllist[j] == whiteurl)
				found = true; 
			j++;
		}
		if (!found){
			urllist = urllist.concat([whiteurl]);
		}
	} else			   
		urllist = [whiteurl];	
	
    return urllist;	
}

/*Path pattern matching — for example, /*, /foo* , or /foo/bar matches. 
Detail: path — for example, /*, /foo* , or /foo/bar */  
function pathPattMatch (p1, p2) {
	var patt = new RegExp(p1, "i");  // /p1*/i pattern (e.g '/')
	if (patt.test(p2))    			// e.g. '/src' match pattern '/*'
		return true;
		
	return false;
}

/*Check if domain and name of two cookies match. */
function cookieNameDomMatch(c1, c2) {
	return c1.name === c2.name && domainMatch (c1.toString(), c2.toString()); //c1.domain === c2.domain;
}

/*Returns an object containing cookie flags and extension related information. 
The parameter is the string version of the object. */
function parseCookieStr (cookieEntry) {
	var entry = cookieEntry; 
	var items = entry.split("**");
		
	var secure = (items[4] == "true") ? true : false;
	var httponly = (items[5] == "true") ? true : false;
	var securesetext = (items[6] == "true") ? true : false;
	var httpsetext = (items[7] == "true") ? true : false;
	var session = (items[8] == "true") ? true : false;
	var reverted = (items[9] == "true") ? true : false;
	
	var cookieObj = {name: items[0], domain: items[1], path: items[2], 
					value: items[3], secure: secure, httponly: httponly,
					securesetext: securesetext, httpsetext: httpsetext, session: session, reverted: reverted};
	return cookieObj;
}

/*Checks if the base domain (object) is in the list of urls */
function isDomainInUrls (domain, listurl) {
	if (!listurl.length > 0) 
		return false;
	for (var i = 0; i < listurl.length; i++) {
		if (domain === getUrlBaseDomain(URI(listurl[i])))
			return true;
	}
}
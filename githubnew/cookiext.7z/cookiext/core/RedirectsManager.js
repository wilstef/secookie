/*The redirect manager is used to manage the automatic redirection by the extension from HTTP to HTTPS and
all related issues (whitelisting, etc). User allowed redirects (from HTTP to HTTPS) store the following information:
	id (key in the database), domain
Redirect messages are shown to the user when performing a HTTP to HTTPS redirect that s/he may want to allow: we keep
track of tab identifiers where we should show the message. */
function RedirectsManager(eventsManager, database, redirectsData, cookiesStore, statsOn) {
	this.eventsManager = eventsManager;
	this.database = database;
	this.cookiesStore = cookiesStore; //Check if a request should be upgraded or not (looking for an upgraded cookie)
	this.redirects = {};
	this.redirectMessages = [];
	this.whitelistMessages = {};
	this.lastId = 0;
	for (var i = 0; i < redirectsData.length; i++) {
		this.redirects[redirectsData[i].domain] = redirectsData[i];
		this.lastId = Math.max(this.lastId, redirectsData[i].id);
	}
	this.statsOn = statsOn; //Turning on and off the statistics 	
}

/*Initialize a redirect object for a certain site. */
RedirectsManager.prototype.createRedirectObject = function (domain) {
	this.redirects[domain] = {
		domain: domain,
		userRedirect: false,
		autoRedirectPages: false,
		autoRedirectResources: false,
		whitelistPages: [],
		id: ++this.lastId
	};
};

/*Mark a certain domain as allowed by the user to perform HTTP to HTTPS redirections. */
RedirectsManager.prototype.addUserRedirect = function (domain) {
	if (!this.redirects.hasOwnProperty(domain))
		this.createRedirectObject(domain);
	this.redirects[domain].userRedirect = true;
	this.database.put(this.redirects[domain]);
	debug("Added user redirect on domain {0}".format(domain), DEBUG_REDIRECTS);
};

/*Add an automatic HTTP to HTTPS redirect. We apply the redirection to all requests matching the domain of the
given URL. */
RedirectsManager.prototype.addAutoRedirect = function (domain) {
	if (!this.redirects.hasOwnProperty(domain))
		this.createRedirectObject(domain);
	this.redirects[domain].autoRedirectPages = this.redirects[domain].autoRedirectResources = true;
	this.database.put(this.redirects[domain]);
	debug("Added automatic redirect on domain {0}.".format(domain), DEBUG_REDIRECTS);
};

/*Add a request, previously redirected automatically by the extension, to the whitelist: the whitelist
contains only references to pages. */
RedirectsManager.prototype.addWhitelist = function (url, type, tabId) {
	var domain = url.domain();
	var updateDb = false;
	if (!this.redirects.hasOwnProperty(domain))
		this.createRedirectObject(domain);
	if (type.isIn(PAGE, FRAME, AJAX)) {
		var whiteUrl = removeQueryString(url);
		if (this.redirects[domain].whitelistPages.indexOf(whiteUrl) === -1) {
			this.redirects[domain].whitelistPages.push(whiteUrl);
			this.addWhitelistMessage(url, tabId);
			debug("Added page {0} to whitelist.".format(whiteUrl), DEBUG_REDIRECTS);
			updateDb = true;
		}
	} else if (this.redirects[domain].autoRedirectResources) {
		this.redirects[domain].autoRedirectResources = false;
		debug("Whitelisted resources on {0}".format(domain), DEBUG_REDIRECTS);
		updateDb = true;
	}
	if (updateDb)
		this.database.put(this.redirects[domain]);
};

/*Remove all redirects from the store. */
RedirectsManager.prototype.removeAllRedirects = function () {
	for (var domain in this.redirects)
		this.database.remove(this.redirects[domain].id);
	this.redirects = {};
	console.log("Redirects cleared ... ");
};

/*Get all stored redirects. */
RedirectsManager.prototype.getRedirects = function () {
	var redirects = [];
	for (var domain in this.redirects)
		redirects.push(this.redirects[domain]);
	return redirects;
};


/*Check if the domain of a request is already in auto-redirects list. */
RedirectsManager.prototype.isInAutoRedirects = function (request){
	var url = URI(request.url);
	var domainRedirects = this.redirects[url.domain()];	
	if (!this.redirects.hasOwnProperty(url.domain()))
       return false;
	   
	return domainRedirects.autoRedirectPages || domainRedirects.autoRedirectResources;
};

/*Check if the domain of a main page, frame or AJAX request is already in auto-redirects list. */
RedirectsManager.prototype.isInAutoRedirectPages = function (request){
	var url = URI(request.url);
	var domainRedirects = this.redirects[url.domain()];	
	if (!this.redirects.hasOwnProperty(url.domain()))
       return false;
	   
	return domainRedirects.autoRedirectPages;
};

/*Check if a request should be upgraded by the extension when the onBeforeRequest event is fired. 
 A request should be upgraded if:
  - the domain (in the request URL) is marked to be auto-redirected;
  - the request, if is a page/frame/AJAX request, is not white-listed for HTTP communication. */
RedirectsManager.prototype.shouldUpgrade = function (request) {
	var url = URI(request.url);
	var redirect = false;
	
	var whitelistedPage = false;
	var inAutoRedirectsPage = false;
	var inAutoRedirectResource = false;
	var isPFARequest = request.type.isIn(PAGE, FRAME, AJAX);  //The request is a main page, frame or AJAX
	var hasSecuredCookie = this.cookiesStore.hasSecuredCookies(url);
	
	if (this.redirects.hasOwnProperty(url.domain())) {
		var domainRedirects = this.redirects[url.domain()];
	    if (isPFARequest){
			inAutoRedirectsPage = domainRedirects.autoRedirectPages;
			whitelistedPage = (domainRedirects.whitelistPages.indexOf(removeQueryString(url)) != -1);
			}
		else 
			inAutoRedirectResource = domainRedirects.autoRedirectResources;
	}
	
	/*A non white-listed page/frame/AJAX request is upgraded if there has been a login operation in the past, 
	 successful or redirected to HTTP, and a session cookie was found. */
	var c1 = isPFARequest &&   //The request is a main page, frame or AJAX.
		(inAutoRedirectsPage &&	//The domain is in the auto-redirect list (e.g., there has been a login to the domain over HTTPS).
		hasSecuredCookie) &&   //There is at least a session cookie marked Secure by the extension for this URL.
		!whitelistedPage;   //The domain is not white-listed for pages/frame/AJAX.
	var c2 = !isPFARequest && (inAutoRedirectResource &&   //The domain is in the auto-redirect list (e.g., there has been a login to the domain over HTTPS)
		hasSecuredCookie); //There is at least a session cookie marked Secure by the extension for this URL.
	
	redirect = c1 || c2;
	
	debug("Request to url {0} should {1}be redirected.".format(url, redirect ? "" : "not "), DEBUG_REDIRECTS);
	return redirect;
};

/*Check if a request is whitelisted. */
RedirectsManager.prototype.isWhitelisted = function (request) {
	var url = URI(request.url);
	var domain = url.domain();
	if (!this.redirects.hasOwnProperty(domain))
		return false;
	return !request.type.isIn(PAGE, FRAME, AJAX) ? this.redirects[domain].autoRedirectResources : 
		this.redirects[domain].whitelistPages.indexOf(removeQueryString(url)) !== -1;
};

/*The method handle errors occurred during redirections: it is called when requests are aborted because of HTTPS
failure. The first parameter is the request for which the error has been generated.*/
RedirectsManager.prototype.handleErrors = function (request) {
	/*Add URL to white-listed list and fall-back to HTTP. */
	var url = URI(request.url).protocol(HTTP);
	this.addWhitelist(url, request.type);  //Fragment and query is removed.
	this.cookiesStore.revertCookies(request); //Revert the Secure flag of all the cookies set for this URL.
			
	/*Update extension white-list and redirected lists. */
	if (this.statsOn)
		 updateStatistics(request, 'SSL_RELATED_ERROR');
			
	debug("Fallback to HTTP for {0}. Request type: {1}".format(url, request.type), DEBUG_REDIRECTS);
	if (request.type === PAGE) {
		/*Main page: reload the page. Add also an event (otherwise, if taints would be used, the reload would be 
		marked as tainted as the request is redirected from https://... to http://... (cross-origin)). */
		this.eventsManager.addEvent({
			url: url.toString(),
			type: FALLBACK
		}, request.tabId); 
		
		/*Delete the tab waiting for the redirected request (to avoid Chrome error message
		 and then is replaced by the downgraded page. Creates problem in yahoo case. */
		chrome.tabs.remove(request.tabId, function () {			
			chrome.tabs.create({"url": request.url.replace('https', 'http'), "selected": true});
		});
		
		//chrome.tabs.update(request.tabId, {url: url.toString()}); // Reload the page
				
	} else if (request.type.isIn(IMAGE, SCRIPT, STYLESHEET, FRAME)) {  //Reload only the sub-resource using content script
		/*Send a message to the content script to downgrade the request. */
		chrome.tabs.sendMessage(request.tabId, {
			url: url.toString(),
			type: FALLBACK,
			requestType: request.type
		});
	}
};

/*Check if the redirect described by the two URLs is allowed. If it is not only because the user has not confirmed
the redirect, add a redirect message to the tab, in order to be shown when the page is loaded. The two URL parameters
must be URI objects. */
RedirectsManager.prototype.askUserRedirect = function (fromUrl, toUrl, tabId) {
	if (fromUrl.protocol() === HTTP && toUrl.protocol() === HTTPS && URI(fromUrl).protocol(HTTPS).equals(toUrl)) {
		var domain = fromUrl.domain();
		if (!this.redirects.hasOwnProperty(domain) || !this.redirects[domain].userRedirect && 
			!this.redirects[domain].autoRedirectPages) {
			debug("Tab {0}: adding message from {1} to {2}".format(tabId, fromUrl, toUrl), DEBUG_REDIRECTS);
			this.redirectMessages.push(tabId);
		}
	}
};

/*Check if there is a redirect message for a certain tab: if present, remove it from the list. */
RedirectsManager.prototype.checkRedirectMessage = function (tabId) {
	var idx = this.redirectMessages.indexOf(tabId);
	if (idx !== -1) {
		this.redirectMessages.splice(idx, 1);
		return true;
	}
	return false;
};

/*Add a whitelist message related to the given URL to be shown in the given tab. */
RedirectsManager.prototype.addWhitelistMessage = function (url, tab) {
	if (!this.whitelistMessages.hasOwnProperty(tab))
		this.whitelistMessages[tab] = [];
	this.whitelistMessages[tab].push(url);
};

/* Check if there is a whitelist message for a certain tab and return the message string.
Delete also the messages from the list. */
RedirectsManager.prototype.getWhitelistMessage = function (tab) {
	if (!this.whitelistMessages.hasOwnProperty(tab))
		return null;
	var messages = [];
	for (var i = 0; i < this.whitelistMessages[tab].length; i++)
		messages.push(WHITELISTED_MESSAGE.format(this.whitelistMessages[tab][i]));
	delete this.whitelistMessages[tab];
	return messages.join("");
};
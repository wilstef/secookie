/*The pages store keeps track of all pages currently open in the browser. */
function PagesStore(tabs) {
	this.openPages = {};
	for (var i = 0; i < tabs.length; i++)
		this.addPage(tabs[i].id, URI(tabs[i].url), false, false); // maybe tainted flag should be replaced.
}

/*Add a new page to the store. For each page keep track of the URL (the request that has retrieved it is always un-tainted). */
PagesStore.prototype.addPage = function (tabId, url, tainted, extUpdated) {
	this.openPages[tabId] = {
		url: url, tainted: tainted, extUpdated: extUpdated
	};
	debug("Adding page {0} to tab {1}. Tainted? {2}".format(url, tabId, tainted), DEBUG_PAGES);
};

/*Check if a page with the given tab identifier exists in the pages store. */
PagesStore.prototype.exists = function (tabId) {
	return this.openPages.hasOwnProperty(tabId);
};

/*Remove the page associated to the specified tab identifier. */
PagesStore.prototype.removePage = function (tabId) {
	if (this.exists(tabId))
		delete this.openPages[tabId];
};

/*Return the tainted marker of the page (or true if there is no such page). */
PagesStore.prototype.isTainted = function (tabId) {
	if (this.exists(tabId))
		return this.openPages[tabId].tainted;
	return true;
};

/*Retrieve the URL of the page with the specified tab identifier. */
PagesStore.prototype.getUrl = function (tabId) {
	if (this.exists(tabId))
		return this.openPages[tabId].url;
	return null;
};

/*Check if the protocol of the URL associated to the page is HTTPS. */
PagesStore.prototype.isHttps = function (tabId) {
	if (!this.exists(tabId))
		return null;
	return this.openPages[tabId].url.protocol() === HTTPS;
};

/*Check if a page can be downgraded to HTTP due to a JavaScript redirect. */
PagesStore.prototype.allowDowngrade = function (tabId, newUrl) {
	if (!this.exists(tabId) || !newUrl.protocol(HTTPS).equals(this.openPages[tabId].url))
		return false;
    /*If the previous page (in the current tab) was upgraded by the extension ('tainted' value is always 'false'). */
	return this.openPages[tabId].extUpdated && !this.openPages[tabId].tainted;
};
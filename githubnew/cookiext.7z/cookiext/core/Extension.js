/*Extension core. */
/*Object constructor (a function) to construct (an instance of) the object. As there may be more than
 one instance of the object Extension, "this" is the instance of the object at hand and each property
 preceded by "this" indicates the property belongs to the (current) instance of the object at hand. 
 More details and examples here: http://www.w3schools.com/js/js_objects.asp */
 
function Extension(cookies, tabs, preferences, dbRedirects, redirectsData,
	dbSecuredCookies, securedCookies, statsOn) {
	this.connectionsStore = new ConnectionsStore();
	this.pagesStore = new PagesStore(tabs);
	this.cookiesStore = new CookiesStore(cookies, dbSecuredCookies, securedCookies,
		preferences.minimumLength, preferences.randomnessThreshold, statsOn);
	this.eventsManager = new EventsManager();
	this.redirectsManager = new RedirectsManager(this.eventsManager, dbRedirects, redirectsData, this.cookiesStore, statsOn); // Added: this.cookiesStore
	this.statistics = new Statistics(preferences.minimumLength, preferences.randomnessThreshold);
	this.statsOn = statsOn;
}

Extension.prototype.showManager = function () {
	var manager_url = chrome.extension.getURL("manager/manager.html");
	chrome.tabs.create({"url":manager_url, "selected":true});
};

/*Add a website to the list of white sites. For a white site, 
the extension does not set HttpOnly flag of cookies for that site. This is needed for usability reasons, such as
the cookies 'c_user' in facebook, 'js_csrf' in dropbox, 'GMAIL_AT' in gmail and 'FIFACom' by fifa should not be set as HttpOnly. */
/*The sites that needs to be whitelisted for HttpOnly flag: 
 facebook.com, gmail.com, dropbox.com, kth.se, girlsgogames.com*/
Extension.prototype.addWhiteSites = function(url, tabid) {
	this.cookiesStore.addWhiteSites(url, tabid);
};


//Rewriting list. TODO: It should have been implemented as indexed database as the other storages
var rewritings = []; //List of strings (src, dst pair of rewritings)

//Populates the rewriting list 
chrome.storage.local.get("rewritings", function (items) { //items: Object with items in their key-value mappings.
  if(items["rewritings"]) {
    rewritings = items["rewritings"].split(";");  
  }  
});

chrome.extension.onMessage.addListener(  
  function(request,sender,sendResponse) {
   //Add to the re-writing list
   if (request["src"] && request["dst"]) {
      chrome.storage.local.get("rewritings", function (items) {
        if (items["rewritings"]) {
          var found = false;
          var entries = items["rewritings"].split(";");
          entries.forEach (function (entry) {
            var sd = entry.split(",");
            if (sd[0] == request["src"])
              found = true;
          });
          if (!found)
            chrome.storage.local.set({"rewritings": items["rewritings"] + ";" + request["src"] + "," + request["dst"]});
        }
        else {
          chrome.storage.local.set({"rewritings": request["src"] + "," + request["dst"]});
        }
      }); 
    }
	
	//Deletes an entry from the re-writing list
	if (request["del_src"] && request["del_dst"]) {
        chrome.storage.local.get("rewritings", function (items) {
          var entries = items["rewritings"].split(";");
          var new_hosts = "";
          entries.forEach (function (entry) {
            var sd = entry.split(",");
            if (sd[0] != request["del_src"] || sd[1] != request["del_dst"]) {
              new_hosts = new_hosts + sd[0] + "," + sd[1] + ";";
            }
          });
          new_hosts = new_hosts.substring(0, new_hosts.length - 1);
          chrome.storage.local.set({"rewritings": new_hosts});
        });
      }
});

/*If the request URL matches with any source in custom redirections, return the 
  destination URL, otherwise empty string. */
function isInCustRewriting(url) {
	var i = 0;
	var desturl = "";
	while (rewritings && i < rewritings.length) {
		var entries = rewritings[i].split(",");
		var patt = new RegExp(entries[0]);
		if (patt.test(url))
			desturl = entries[1];
		i++;	   
	}
	
//Check if the URL is a valid one (URL without protocol can not be redirected)
//Currently, we assume the user types in the correct URL
//	var pattern = /.http.*/i;
//	if(!pattern.test(desturl) && desturl != "")
//		desturl = "http://" + desturl; //Add protocol (by default http)
		
return desturl;
}


/*Callback method used for redirecting HTTP requests to HTTPS. Requests not related to tabs are not considered.
The parameter is an object with fields described here:
http://developer.chrome.com/extensions/webRequest.html#event-onBeforeRequest */
Extension.prototype.upgradeRequest = function (request) {
	if (request.tabId == -1)
		return; 

		
	//If the request URL is in the custom redirections, redirect the request to the new destination. 
	if(request.type == PAGE){
		var newurl = isInCustRewriting(JSON.stringify(request.url));
		if(newurl != "")
			return {redirectUrl: newurl};
	}
		  
	var url = URI(request.url); //Remove query and fragment parts from the url string.
			
	var evt = this.eventsManager.searchEvent(request, false);
	
	/*Check if a page can be downgraded to HTTP due to a JavaScript redirect. */
	if (url.protocol() === HTTP && this.pagesStore.allowDowngrade(request.tabId, URI(url))) {
		this.redirectsManager.addWhitelist(url, request.type, request.tabId);
		/*JavaScript redirect is also considered as server redirect. For example, the 'window.location' object
		can be used to get the current page address (URL) and to redirect the browser to a new page, such as 
		window.location.replace(...) will simulate an HTTP redirect.. */
		if (this.statsOn)
			updateStatistics(request, 'SERVER_REDIRECT');
	}
		
	//Check if a request is a login operation. 
	var login = false;
	
	//We can check login early in onBeforeRequest as in analyzeRequest, formData is not available...
	if(request.method === POST && request.hasOwnProperty("requestBody") && 
		request.requestBody.hasOwnProperty("formData") && isLoginOperation(URI(url), request.requestBody.formData)){
	    login = true;
		
		if (this.statsOn)
			updateStatistics(request, 'ADD_REQUEST_LOGIN');		
			
		this.eventsManager.addLogin({
			method: POST,
			type: LOGIN_OPERATION,
			formAction: null,  //Action can't be extracted here, its null by default...
			openerTab: request.tabId,
			referer: request.url
		});
	}
	
	//Add the login connection.
	if ( login || (evt !== null && evt.type.isIn(ADDRESS_BAR, LOGIN_OPERATION, REDIRECT, FALLBACK)) )
		this.connectionsStore.addConnection(request, false, login); //Taints are not used in CookiExt, its always false (un-tainted) 
	
	/*If a request URL is originally HTTPS, don't redirect it to the same URL. This if-statement was added after we faced troubles with
	vevo.com signing-in. The AJAX request (https://apiv2.vevo.com/me?token=fiYoE...) after user enters password could not be redirected
	properly from https://... to https://... Such redirects are possible for any URL, except this one. In situation where the URL is 
	HTTPS, no up-gradation is needed. So the above problem can be avoided by skipping redirection if URL is HTTPS like the above one. */
	if (url.protocol() === HTTPS)
		return; 
	
	/*Upgrade is done only if:
	- requests are related to a tab (request.tabId !== -1) or a login operation and;
	- the protocol of the request is HTTP and;
	- the site is not white-listed and marked to be auto-redirected;
	- we are not causing a redirect loop;
	- the request, if it is for a sub-resource, is related to a HTTPS page. */
	if ((request.tabId !== -1 || (login || evt !== null && evt.type === LOGIN_OPERATION)) && url.protocol() === HTTP &&
		(request.type === PAGE || this.pagesStore.isHttps(request.tabId) && request.tabId !== -1) &&
		this.redirectsManager.shouldUpgrade(request)) {  
		if (request.type === PAGE)
			debug("{0} should be redirected.".format(url), DEBUG_REDIRECTS);
		if (evt !== null)
			this.eventsManager.changeProtocol(request, HTTPS);
		else {
			if (!this.connectionsStore.exists(request))
				this.connectionsStore.addConnection(request, false, false); //Second argument is for taint. non-tainted by default as taints are not dealt with in Cookiext
			this.connectionsStore.addRedirect(request, EXTENSION_REDIRECT);
		}

		/*Modify the protocol and redirect the connection. */		
		request.url = url.protocol(HTTPS).toString();
		debug("Redirection: {0}".format(request.url), DEBUG_REDIRECTS);
		
		//Update redirected list statistics.
		if (this.statsOn)
			updateStatistics(request, 'REQUEST_UPDATED');
				
		return {redirectUrl: request.url};
	}
		
	return {redirectUrl: request.url};
};

/*Callback method to perform the analysis of outgoing requests. Requests not related to tabs are not considered.
The parameter is an object with fields described here:
http://developer.chrome.com/extensions/webRequest.html#event-onBeforeSendHeaders */
Extension.prototype.analyzeRequest = function (request) {  // Unlike, onBeforeRequest, analyzeRequest does not contain 'formData'. It is always null.
	var evt = (request.type.isIn(PAGE, FRAME)) ? this.eventsManager.searchEvent(request, true) : null;
	if (request.tabId === -1 && evt === null) return;
	
	var url = URI(request.url);
	
	//Count the request if the user has logged into the site.
	if (this.statsOn )
		updateStatistics(request, 'ADD_REQUEST'); 	
		
	var attachCookies = true;
	var redirect = this.connectionsStore.isARedirect(request);
	
	/*Add connection to the connection store. */
	if (evt !== null && evt.type.isIn(ADDRESS_BAR, LOGIN_OPERATION, REDIRECT, FALLBACK) ) {
		this.connectionsStore.addConnection(request, false, false); // second argument for taint. Un-tainted by default. 
		if (request.type === PAGE) {
			this.eventsManager.flushTabEvents(request.tabId);
		}
	} 
	
	/*Modify request headers if needed: if the computed cookie string is empty or no cookies should be attached,
	remove the header line. FIXME: As we now 'revert' cookies in the store when a fall-back is detected, extending
    cookies in the request header is not needed. As the revert operation is asynchronous (the revert operation may 
    update the store after the request is sent), therefore we keep this format.	*/
	var idx = indexHeader(request.requestHeaders, "cookie");
	var cookieString = "";
	if (attachCookies) { //Returns set of cookies separated by ';' including non-secure and Secure (even if HTTP if secured by extension)
		cookieString = computeCookieString(this.cookiesStore.selectCookies(url,
			this.redirectsManager.isWhitelisted(request) && request.type.isIn(PAGE, FRAME, AJAX))); 
			//If the page/frame/AJAX request is white-listed, extend set of cookies with those marked Secure by the extension
	}
			
	if (cookieString !== "") {
		if (idx !== -1)
			request.requestHeaders[idx].value = cookieString;
		else
			request.requestHeaders.push({name: "Cookie", value: cookieString});
		if (request.type.isIn(PAGE, AJAX))
			debug("Attaching cookies for {0}: {1}".format(url, cookieString), DEBUG_COOKIES);
	} else if (idx !== -1) {
		request.requestHeaders.splice(idx, 1);
		if (request.type.isIn(PAGE, AJAX))
			debug("Not attaching cookies for {0}.".format(url), DEBUG_COOKIES);
	}
	
	return {requestHeaders: request.requestHeaders};
};

/*Revert cookies in the store if a fall-back is detected and add the site to white list. Such fall-back
is requested by the server through HTTP header and is considered secure. In addition, the statistics are updated. */
Extension.prototype.handleRedirect = function (details) {
	var reqUrl = URI(details.url);
	var redUrl = URI(details.redirectUrl);
    var reqProt = reqUrl.protocol(); 
	var redProt = redUrl.protocol();
    var domreqUrl = reqUrl.domain(); 
	var domredUrl = redUrl.domain();
	
	//Only protocol based (HTTPS to HTTP) URL redirections are considered 
	if(removeQueryString(reqUrl).toString().replace('https', 'http') == removeQueryString(redUrl) && reqProt != redProt) { //If it is a server redirect to HTTP	 	 
    	this.redirectsManager.addWhitelist(redUrl, details.type, details.tabId);
		this.cookiesStore.revertCookies(details); //Revert the Secure flag of all the cookies set for this URL.
				
		if (this.statsOn)
			updateStatistics(details, 'SERVER_REDIRECT');
	}  	
};

/*Callback method to perform the analysis of incoming responses. Requests not related to tabs are not considered.
The parameter is an object with fields described here:
http://developer.chrome.com/extensions/webRequest.html#event-onHeadersReceived */
Extension.prototype.analyzeResponse = function (response) {
	if (response.tabId === -1) return;	
		
	var url = URI(response.url); //URL without fragment parts
		
	var isinautoredirect = this.redirectsManager.isInAutoRedirectPages(response);
			
	/*Inform script that the response is for a login request and domain is not already in auto-redirects.
	TODO: It further needs to refine to make it more robust. Especially, to ignore successful login redirects and
	check the next request to URL (whom it is redirected to). Moreover, the form id (name plus id) may be stored in 
	each connection to determine if a login form other than the one submitted is received, it should not be considered
	login failure (see getFormHeaderElementValue() function in content.js). */
	if (	response.type.isIn(PAGE, FRAME, AJAX) &&
			this.connectionsStore.isLoginConnection(response) && 
			!isinautoredirect) {
	    chrome.tabs.onUpdated.addListener(function (tabId){ //Call content after the new page is loaded and then detect login form there.
			if (tabId == response.tabId){
				chrome.tabs.sendMessage(response.tabId, {
					type: 'LOGIN-OPERATION',
					url: url.toString()
				});
			}
		});
	} /*In manager, user can clear database and loged-sites, but not auto-redirects in memory. To be consistent, add the site to logged-sites
	  TODO: loged-in sites list should be moved to RedirectsManager.js from Statistics.js. */
	else if (isinautoredirect) {   
			var site = getUrlBaseDomain(url);
			statsAddLogedInSites (site);
		}
	 			 
	var evt = (response.type.isIn(PAGE, FRAME)) ? this.eventsManager.searchEvent(response, true) : null; 
		
	//Check if the response domain is white-listed 
	var whitelisted = this.redirectsManager.isWhitelisted(response);	
	
	/*Update the tab identifier */
	this.connectionsStore.updateTabId(response);
	
	/*Secure update: A non-secure cookie is not allowed to replaced an originally secured and HttpOnly cookie. 
	As CookiExt currently is designed to protect sessions, this operation is not really needed, however, it
	does not modify the browser behaviour to much, we keep it. */
	//The third argument is by default false (un-tainted)
	
	var newHeaders = this.cookiesStore.secureUpdate(url, response.responseHeaders, false, whitelisted, response); 
	
	/*Remove the connection from the connection store if we are not being redirected and add the page to the
	pages store if the response refers to the main frame of a page. */
	if (/^HTTP\/1.[01] 30[0-37] /.test(response.statusLine)) {  //Server redirect such as "HTTP/1.1 301 Moved Permanently", 302 is a server redirect						
		this.connectionsStore.addRedirect(response, SERVER_REDIRECT);
		
		/*Solves redirect loops such as for http://slashdot.org/my/login, from: https://slashdot.org/index2.pl, 
		to: http://slashdot.org/ then from: https://slashdot.org/, to: http://slashdot.org/index2.pl */
		if (this.connectionsStore.loopingRedirect(response)) {
			var whitelistedUrls = this.connectionsStore.computeWhitelistedUrls(response);
			for (var i = 0; i < whitelistedUrls.length; i++)
				this.redirectsManager.addWhitelist(URI(whitelistedUrls[i]), response.type, response.tabId);
		} else { 
			//Add to auto-redirects if a connection is a login that has been redirect from HTTPS to HTTP.
			if (this.connectionsStore.loginRedirectedToHttp(response)) { ////Updated: 
				/*Add the site to loged-in list if login was successful. */
				if (this.statsOn) {
					var site = getUrlBaseDomain(url);
					if (!isSiteInLogedIn (site)) {
						statsAddLogedInSites (site);
						console.log("Site added to loged-in (logged in over https but then fall-back): " + site);
					}		
				}
				this.redirectsManager.addAutoRedirect(url.domain());
			 //No need to check if the redirect is allowed.
			} /*corresponds to Status: HTTP/1.1 404 Not Found on Accelerator e.g.,  https://answers.yahoo.com/, its not redirect. */
		}
	} else if (/^HTTP\/1.[01] [45]\d\d /.test(response.statusLine) && this.connectionsStore.isExtensionRedirect(response)){
		this.redirectsManager.handleErrors(response);
		 }
	else {
		if (response.type === PAGE)
			this.pagesStore.addPage(response.tabId, url, false,   //All connections/pages are un-tainted
				this.connectionsStore.isExtensionRedirect(response));
		this.connectionsStore.removeConnection(response);
	}

	return {responseHeaders: newHeaders};
};

/*Callback method for dealing with requests errors. The parameter is an object whose fields are described here:
http://developer.chrome.com/extensions/webRequest.html#event-onErrorOccurred */
Extension.prototype.handleErrors = function (request) {
	
	this.connectionsStore.removeConnection(request);	
	//If HTTPS URL was entered in address bar, never downgrade
	var evt = this.eventsManager.searchEvent(request, false); 
	var userInitiated = (evt !== null && evt.type == ADDRESS_BAR);
		
	/*The documentation says not to rely on error messages since they are not guaranteed to remain backwards
	compatible, but they are the only way to understand the type of error which has occurred. Moreover, as these
	errors can be controlled by the network attacker, they are not the reliable means of detecting the SSL support
	in the websites. For example, a non-existent link can be injected onto the page, which on redirecting to
    HTTPS will fail and hence the extension will revert all the secured cookies, voiding its effectiveness.	*/
	
	 //Therefore, network errors are completely ignored, as they can be controlled by the network attacker
	/* if (URI(request.url).protocol() === HTTPS && !userInitiated &&
		request.error.isIn("net::ERR_SSL_PROTOCOL_ERROR",
		"net::ERR_CONNECTION_TIMED_OUT", "net::ERR_CONNECTION_REFUSED") && request.type.isIn(PAGE, FRAME, AJAX)) {
		this.redirectsManager.handleErrors(request);
        }
	*/
};

/*Callback method executed when tabs are closed: flush all the requests from the connection store,
remove the page from the page store and clear all events associated to the page in the given tab. */
Extension.prototype.onClosingTab = function (tabId) {
	this.connectionsStore.flushTabConnections(tabId);
	this.eventsManager.removeTabEvents(tabId);
	//this.loginsManager.clearForms(tabId); //remove sessint stuffs
	this.pagesStore.removePage(tabId);
};

/*Callback method to handle cookies modifications. In order to avoid synchronization issues, we update cookies on the
fly when requests are received. We need this event to keep track of cookies deleted due to expiration or added/removed
via JavaScript. The parameter is an object with fields described here: 
http://developer.chrome.com/extensions/cookies.html#event-onChanged */
Extension.prototype.onCookieChange = function (changeInfo) {
	if (!this.cookiesStore.isSyncUpdate(changeInfo.cookie, changeInfo.removed)) {
		if (changeInfo.removed)
			this.cookiesStore.removeCookie(changeInfo.cookie);
		else
			this.cookiesStore.addCookie(changeInfo.cookie);
		debug("Cookie non-sync update: {0}, domain {1}, path {2}, remove {3}".format(changeInfo.cookie.name,
			changeInfo.cookie.domain, changeInfo.cookie.path, changeInfo.removed), DEBUG_COOKIES);
	} else
		debug("Cookie sync update: {0}, domain {1}, path {2}, remove {3}".format(changeInfo.cookie.name,
			changeInfo.cookie.domain, changeInfo.cookie.path, changeInfo.removed), DEBUG_COOKIES);
	debug(JSON.stringify(this.cookiesStore.cookies), DEBUG_COOKIES_VERBOSE);
	debug(JSON.stringify(this.cookiesStore.securedCookies), DEBUG_COOKIES_VERBOSE);
	debug(JSON.stringify(this.cookiesStore.syncUpdated), DEBUG_COOKIES_VERBOSE);
};

/*Callback method executed when the user enters some text using the Chrome omnibox, using the keyword specified in
the manifest file ("g"). This is the only way to detect the usage of the address bar. */
Extension.prototype.onModifiedAddressBar = function (text, tabId) {
	var url = expandUrl(text); //Add the protocol to the url string if not specified.
	this.eventsManager.addEvent({
		type: ADDRESS_BAR,
		url: url
	}, tabId);
	chrome.tabs.update(tabId, {url: url});
};

/*Callback method executed when messages from content scripts are received. */
Extension.prototype.onMessageReceived = function (message, sender, sendResponse) {
	if (message.type === 'NO-LOGIN-FORM-RECEIVED') {
		url = URI(message.url);
		
		/*Add the site to logged-in sites if login was successful. */
		var site = getUrlBaseDomain(url);
		if (!isSiteInLogedIn (site)) {
			statsAddLogedInSites (site);
			console.log("Site added to loged-in: " + site);
		}
				
		/*In addition, add the domain to auto-redirects too if the login was successful over HTTPS. */
		if (!this.redirectsManager.isInAutoRedirects({url: message.url}) && url.protocol() === HTTPS) {
			this.redirectsManager.addAutoRedirect(url.domain());
		}
	}		
	if (message.type === ASK_FOR_MESSAGES && sender.tab !== undefined) {
		if (this.redirectsManager.checkRedirectMessage(sender.tab.id))
			chrome.tabs.sendMessage(sender.tab.id, {type: DISPLAY_REDIRECT_MESSAGE});
		var whitelistMessage = this.redirectsManager.getWhitelistMessage(sender.tab.id);
		if (whitelistMessage !== null)
			chrome.tabs.sendMessage(sender.tab.id, {type: DISPLAY_INFO_MESSAGE, text: whitelistMessage})
	} else if (message.type === REDIRECT) {
		this.eventsManager.addEvent(message, sender.tab.id);
		this.redirectsManager.addUserRedirect(URI(this.pagesStore.getUrl(sender.tab.id)).domain());
		chrome.tabs.reload(sender.tab.id, {bypassCache: true});
	}
};

Extension.prototype.log = function (message) {
	console.log(message);
};
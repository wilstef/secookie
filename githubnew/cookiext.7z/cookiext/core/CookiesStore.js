/* Cookies store implementation. The cookie store of the browser cannot be used since all methods
provided by the API are asynchronous. Cookies object are retrieved from the store, thus they have the
fields described at http://developer.chrome.com/extensions/cookies.html#type-Cookie
while secured cookies are objects with the following fields:
    name, domain, path, if the Secure flag was set by the extension, if the HttpOnly flag was set by 
	the extension and if the Secure flag was reverted back by the extension.
*/

/*As CookiExt sets HttpOnly flag of every non-HTTP session cookie, some websites may
break. For example, facebook and gmail chat and dropbox breaks, as some session cookies ('c_user' in facebook, 'js_csrf' in 
dropbox, ...) may need to be accessed by the script on the pages. To make such sites work, a user may choose to
avoid setting HttpOnly flags of such websites. */
var whitesites = [];  //white list of sites only for HttpOnly flags

function CookiesStore(cookies, dbSecuredCookies, securedCookies, minLength, randThreshold, statsOn) {
	/* Add all cookies to extension store - indexed by domains unlike in the Chrome store 'cookies'. */
	this.cookies = {};
	this.statsOn = statsOn;
	for (var i = 0; i < cookies.length; i++)
		this.addCookie(cookies[i]);
	/*Cookies updated synchronously for which the notification has not been received yet. */
	this.syncUpdated = {};
	/*DB used to keep track of cookies marked as Secure across browsing sessions. */
	this.database = dbSecuredCookies;
	/*Add secured cookies markers to the store (if there are corresponding cookies in the store). */
	this.securedCookies = {};
	this.lastSecuredId = 0;
	for (var i = 0; i < securedCookies.length; i++) {
		if (this.foundMatchingCookie(securedCookies[i]))
			this.addSecuredCookie(securedCookies[i], false);
		else
			this.database.remove(securedCookies[i].id);
		this.lastSecuredId = Math.max(this.lastSecuredId, securedCookies[i].id);
	}
	/*Minimum length for session cookies and threshold for randomness. */
	this.setParameters(minLength, randThreshold);
		
	//Populates the 'logedinsites' from local storage.
	chrome.storage.local.get("whitesites", function (items) { //items: Object with items in their key-value mappings.
	if(items["whitesites"]) {
		whitesites = items["whitesites"].split(";");
	}
	}); 
}

/*Add a new cookie to the store. */
CookiesStore.prototype.addCookie = function (cookie) {
	var index = getCookieBaseDomain(cookie.domain);
	if (!this.cookies.hasOwnProperty(index))
		this.cookies[index] = [];
	this.cookies[index].push(cookie);
	debug("Adding cookie. Name: {0}, domain: {1}, path: {2}".format(cookie.name, cookie.domain, cookie.path),
		DEBUG_COOKIES_VERBOSE);
};

/*Add a website to the list of white sites. For a white site, 
the extension does not set HttpOnly flag of cookies. */
CookiesStore.prototype.addWhiteSites = function (url, tabid) {
	var request = {tabId: tabid, url: url, type: PAGE}; //Request type by default is page
	this.revertHttpOnlyCookies (request);
	
	var url = URI(request.url);
	var basedomain = getUrlBaseDomain(url);
	whitesites = addStrList (whitesites, basedomain.toString());
	
	var sitesStr = whitesites.join(";"); //Joins all the elements of array separated by ";"
	chrome.storage.local.set({"whitesites": sitesStr}); //Updates the local storage. 
	
	return;
}

/*Checks if the site (its base domain) is in the list of white sites. The parameter
is the base domain object. */
CookiesStore.prototype.isSiteWhite = function(basedomain) {	
	if (!whitesites.length > 0)
		return false;
	for (i=0; i<whitesites.length; i++)
		if (basedomain.toString() == whitesites[i])
			return true;
	
	return false;
};

/*Remove a cookie from the store and eventually from the list (and DB) of secured cookies if specified. */
CookiesStore.prototype.removeCookie = function (cookie) {
	var index = getCookieBaseDomain(cookie.domain);
	if (this.cookies.hasOwnProperty(index)) {
		var found = false;
		for (var i = 0; i < this.cookies[index].length && !found; i++)
			found = cookieMatch(this.cookies[index][i], cookie);
		if (found) {
			this.cookies[index].splice(i - 1, 1);
			if (this.cookies[index].length === 0)
				delete this.cookies[index];
			debug("Removing cookie. Name: {0}, domain: {1}, path: {2}".format(cookie.name, cookie.domain, cookie.path),
				DEBUG_COOKIES_VERBOSE);
			this.removeSecuredCookie(cookie);
		}
	}
};

//For debugging. Delete session 
CookiesStore.prototype.deleteSession = function() {
  chrome.cookies.getAll({}, function (cookies) {
    cookies.forEach (function (cookie) {
      if (statIsSessCookie(cookie)) {
	    console.log("Cookie: " + cookie.name);
        var url = "http" + (cookie.secure ? "s" : "") + "://" + cookie.domain + cookie.path;
        chrome.cookies.remove({"url": url, "name": cookie.name});
      }
    });
  });
}

//For debugging. Removes all the cookies from 'this.cookies' store
CookiesStore.prototype.removeAllCookies = function () {
	this.deleteSession();
	this.cookies = {};	
	return;
};

/*Mark a cookie as secured by the extension and save it to the database, if specified.
The parameter must already be a secured cookie object. */
CookiesStore.prototype.addSecuredCookie = function (secCookie, dbSave) {
	var index = getCookieBaseDomain(secCookie.domain);
	if (!this.securedCookies.hasOwnProperty(index))
		this.securedCookies[index] = [];
	this.securedCookies[index].push(secCookie);
	if (dbSave) {
		//globalSecCookies.push(secCookie);
		//console.log("Secured: " + secCookie.name);
		this.database.put(secCookie);
		//secCookiesDb.put(secCookie); //Added: to update the database immediately.
	}
	debug("Adding secured cookie. Name: {0}, domain: {1}, path: {2}".format(secCookie.name, secCookie.domain,
		secCookie.path), DEBUG_COOKIES_VERBOSE);
};

/*Remove the secure marker of the given cookie, if set. */
CookiesStore.prototype.removeSecuredCookie = function (cookie) {	
	var index = getCookieBaseDomain(cookie.domain);
	if (this.securedCookies.hasOwnProperty(index) && this.securedCookies[index].length > 0) {
		var secFound = false; 
		for (var i = 0; i < this.securedCookies[index].length && !secFound; i++){
			secFound = cookieMatch(cookie, this.securedCookies[index][i]);
		}
		if (secFound) {
			//console.log(message + cookie.name); //JSON.stringify(this.securedCookies[index][i - 1]));
			
			debug("Removing secured cookie. Name: {0}, domain: {1}, path: {2}, id: {3}".format(cookie.name, cookie.domain,
				cookie.path, this.securedCookies[index][i - 1].id), DEBUG_COOKIES_VERBOSE);
				
			/*Remove the cookie from the secured cookies database. The 'remove' command
			could be used directly, but that does not update the database 'secCookiesDb'
			even after removal is successful and hence the secured cookie will still be 
			counted in statistics. Need to fix in future. 	*/
			//removeSecCookieDb (cookie);
			this.database.remove(this.securedCookies[index][i - 1].id);				
			this.securedCookies[index].splice(i - 1, 1);
			if (this.securedCookies[index].length === 0)
				delete this.securedCookies[index];
		}
	}
};

/*Check if the given cookie has been marked as secure by the extension. The parameter is a cookie object. */
CookiesStore.prototype.isSecuredCookie = function (cookie) {
	var index = getCookieBaseDomain(cookie.domain);
	if (!this.securedCookies.hasOwnProperty(index))
		return false;
	for (var i = 0; i < this.securedCookies[index].length; i++)
		if (cookieMatch(cookie, this.securedCookies[index][i]))
			return this.securedCookies[index][i].securesetext; // A cookie is in 'secured' list and its secure flag was set by the extension
	return false;
};

/*Check if a secured cookie should be associated to a request to the given URL. The parameter is a URI object. */
CookiesStore.prototype.hasSecuredCookies = function (url) {
	var index = getUrlBaseDomain(url);
	if (!this.cookies.hasOwnProperty(index))
		return false;
	for (var i = 0; i < this.cookies[index].length; i++) {
		var cookie = this.cookies[index][i];
		if (domainMatch(cookie.domain, url.hostname()) && pathMatch(cookie.path, url.path()))
			return true;
	}
	return false;
};

/*Mark the given cookie as updated synchronously. */
CookiesStore.prototype.addSyncUpdate = function (cookie, type) {
	debug("Marking {0}={1} as sync updated.".format(cookie.name, cookie.value), DEBUG_COOKIES);
	var index = getCookieBaseDomain(cookie.domain);
	if (!this.syncUpdated.hasOwnProperty(index))
		this.syncUpdated[index] = [];
	this.syncUpdated[index].push({name: cookie.name, value: cookie.value,
		domain: cookie.domain, path: cookie.path, type: type});
};

/*Given a cookie, search if there is a synchronous update related to it. If the flag 'remove' is set, search among
DELETE and UPDATE events, otherwise search among INSERT and UPDATE events. Remove the event from the array if the
flag is set only for DELETE events, otherwise for INSERT and UPDATE events (because updates are performed as a
two-step operation). */
CookiesStore.prototype.isSyncUpdate = function (cookie, remove) {
	var index = getCookieBaseDomain(cookie.domain);
	if (this.syncUpdated.hasOwnProperty(index)) {
		for (var i = 0; i < this.syncUpdated[index].length; i++) {
			var current = this.syncUpdated[index][i];
			if (cookieMatch(current, cookie) && (current.type === UPDATE || remove && current.type === DELETE ||
				!remove && current.type === INSERT)) {
				if (remove && current.type === DELETE || !remove && current.type.isIn(INSERT, UPDATE)) {
					this.syncUpdated[index].splice(i--, 1);
					if (this.syncUpdated[index].length === 0)
						delete this.syncUpdated[index];
				}
				return true;
			}
		}
	}
	return false;
};

/*Search if there is a cookie in the store matching the given secure cookie. */
CookiesStore.prototype.foundMatchingCookie = function (secCookie) {
	var index = getCookieBaseDomain(secCookie.domain);
	if (!this.cookies.hasOwnProperty(index))
		return false;
	for (var i = 0; i < this.cookies[index].length; i++)
		if (cookieMatch(this.cookies[index][i], secCookie))
			return true;
	return false;
};

/*Method implementing a heuristic based on the index of coincidence to choose if a given cookie is used
for session management. */
CookiesStore.prototype.isSessionCookie = function (cookie) {
	/*Test the cookie name against strings which are known to be commonly used in name
	for session or authentication cookies. */
	var patterns = [/.*sess.*/i, /.*sid.*/i, /.*uid.*/i, /.*user.*/i, /.*auth.*/i, /.*key.*/i]	;
	for (var i = 0; i < patterns.length; i++)
		if (patterns[i].test(cookie.name))
			return true;

	var value = cookie.value;
	try {
		value = decodeURIComponent(cookie.value);
	} catch (err) {}
	/*Too short to be a session cookie. */
	if (value.length < this.minLength)
		return false;
	/*Count character occurrences. */
	var freqs = new Array(256);
	for(i = 0; i < 256; i++)
		freqs[i] = 0;
	for(i = 0; i < value.length; i++)
		freqs[value.charCodeAt(i)]++;
	/*Check if the index of coincidence is below the given threshold. */
	var sum = 0;
	for(i = 0; i < 256; i++)
		sum += freqs[i] * (freqs[i] - 1);
	return (sum / (value.length * (value.length - 1))) < this.randThreshold;
};

/*Return cookies to be attached to a request of the given URL, following the definition of 'get_http_ck'
reported in the SessInt (CSF14). Notice that:
- there may be multiple cookies with the same key (and possibly the same value) that are sent by the browser;
- a cookie with an exact domain match and one with a general sub-domain match have the same precedence.
When there are more matching cookies with the same key, sort them by path length (the longest matching path
appears before in the cookie string). The parameters are the following:
- the URI object representing the target of the request;
- a flag which is true if secured cookies should be attached to an HTTP request. */
CookiesStore.prototype.selectCookies = function (url, httpAttachSecured) {
	var baseDomain = getUrlBaseDomain(url);
	var attached = [];
	if (this.cookies.hasOwnProperty(baseDomain)) { //If there is at least a cookie registered for domain in the Chrome store
		for (var i = 0; i < this.cookies[baseDomain].length; i++) {
			var cookie = this.cookies[baseDomain][i]; //Get the ith cookie for the domain 
			/*Each attached cookie must match the domain and the path. */
			var c1 = domainMatch(cookie.domain, url.hostname()) && pathMatch(cookie.path, url.path());
			/*Each attached session cookie must be HttpOnly and satisfy one of these conditions:
				- the destination page is over HTTP and
					- the cookie is not secure;
					- the cookie has been secured by the extension, the request is for a page (not a sub-resource)
					  and the URL has been white-listed;
				- the destination page is over HTTPS and the cookie is secure.
			Each attached non-session cookie must be either sent through HTTPS or marked as non-Secure. */
		
			if (c1)
				attached.push(cookie);
		}
		attached.sort(function (c1, c2) { return c2.path.length - c1.path.length });
	}	
	return attached;
};

/*Build a cookie object starting from the 'Set-Cookie' string. Compute default attributes for domain and path,
if not specified. Chrome behaviour for the path is the following:
- if there is no '?' in the URL, take everything at the right of the last '/' in the string;
- otherwise take everything before the occurrence of the '?' up to the left-closest '/'. */
var parseAttributes = function (url, setCookieStr, flags) {
	var attributes = setCookieStr.split(";");
	var cookie = split(attributes[0].trim());
	cookie.secure = cookie.httpOnly = false;
	for (var i = 1; i < attributes.length && !flags.trash; i++) {
		var attribute = split(attributes[i].trim());
		attribute.name = attribute.name.toLowerCase();
		if (attribute.name === "httponly")
			cookie.httpOnly = true;
		else if (attribute.name === "secure") {
			if (url.protocol() === HTTPS)
				cookie.secure = true;
			else
				flags.trash = true;
		} else if (attribute.name === "domain" && attribute.value !== "") {
			var domain = computeCookieDomain(url, attribute.value);
			if (domain !== null)
				cookie.domain = domain;
			else
				flags.trash = true;
		} else if (attribute.name === "path" && attribute.value !== "") {
			var path = attribute.value;
			if (path.charAt(0) === "/")
				cookie.path = (path !== "/" && path.charAt(path.length - 1) === "/") ? path.substr(0, path.length) : path;
		} else if (attribute.name === "expires") {
			if (new Date(attribute.value) < new Date())
				flags.cancel = true;
		} else if (attribute.name === "max-age") {
			attribute.value = parseInt(attribute.value);
			if (isNaN(attribute.value) || attribute.value <= 0)
				flags.cancel = true;
		}
	}
	if (!flags.trash) {
		if (!cookie.hasOwnProperty("domain"))
			cookie.domain = url.hostname();
		if (!cookie.hasOwnProperty("path")) {
			var res = url.resource();
			var qm = res.indexOf("?");
			var startSearch = (qm === -1) ? res.length : qm;
			var slashPos = res.lastIndexOf("/", startSearch);
			cookie.path = (slashPos === 0) ? "/" : res.substring(0, slashPos);
		}
	}
	return cookie;
}

/*Secure update cookie operation introduced in SessInt (CSF14): add the HttpOnly flag to all cookies
and the secure flag to all cookies received through HTTPS. Prevent cookies set through HTTPS to be
overwritten by cookies set through HTTP. 
If a session cookie is detected:
- flag it as HttpOnly and Secure if received through HTTPS;
- flag it as HttpOnly if received through HTTP and the URL is whitelisted, otherwise trash it.
The function returns modified response headers to be processed by the browser.
The parameters are the following:
- the URI object representing the URL from which the response was received;
- the response headers to be modified;
- a flag which says if the connection from which we have received the response was tainted or not (it is always un-tainted in CookiExt);
- a flag which says if the URL has already been whitelisted. */
CookiesStore.prototype.secureUpdate = function (url, responseHeaders, tainted, whitelisted, response) {
	for (var i = 0; i < responseHeaders.length; i++)
		if (responseHeaders[i].name.toLowerCase() === "set-cookie") {
			/*Boolean flags related to the cookie that is being built. */
			var flags = {trash: false, cancel: false, toBeSecured: false};
			if (!flags.trash) {
				/*Build a cookie from the 'Set-Cookie' string. */
				var cookie = parseAttributes(url, responseHeaders[i].value, flags);
				
				if (!flags.trash) {
					/*Do not overwrite a secure cookie set through HTTPS (thus not secured by the extension) with a
					non-Secure one. With exception, if the cookie should be cancelled (otherwise it may never be erased). */
					var matchingCookie = null;
					var index = getCookieBaseDomain(cookie.domain);
					if (this.cookies.hasOwnProperty(index))
						for (var j = 0; j < this.cookies[index].length && matchingCookie === null; j++)
							if (cookieMatch(this.cookies[index][j], cookie)) {
								matchingCookie = this.cookies[index][j];
								}
					/*Do not replace an originally Secure and HttpOnly cookie with a non-Secure cookie with the same value. */
					if (!flags.cancel && matchingCookie !== null && matchingCookie.secure &&
						!this.isSecuredCookie(matchingCookie) && matchingCookie.httpOnly &&
						matchingCookie.value === cookie.value && !cookie.secure) {
						flags.trash = true;
						debug("Trying to override secure cookie with a non secure one.", DEBUG_COOKIES);
						debug(JSON.stringify(cookie), DEBUG_COOKIES);
						debug(JSON.stringify(matchingCookie), DEBUG_COOKIES);
					} else {
						var httponlyset = false;  //To track whether or not the HttpOnly flag set by the extension.
						var secureset = false;  //To track whether or not the Secure flag was set by the extension. 
						var issession = false; 
						var orgsecure = cookie.secure;  //Original cookie attributes before extension set the flags.
						var orghttponly = cookie.httpOnly;
						
						//Apply the heuristics to session cookies. 
						if (this.isSessionCookie(cookie)) {								
							issession = true;					
						
							if (!cookie.secure && url.protocol() === HTTPS) {
								responseHeaders[i].value += "; secure";
								cookie.secure = true; //Secure flag was set by the extension
								secureset = true; 
								if (!flags.cancel)
									flags.toBeSecured = true;							
							}							
															
							if (!cookie.httpOnly && !this.isSiteWhite(getUrlBaseDomain(url))){ 
								responseHeaders[i].value += "; httponly";
								cookie.httpOnly = true;
								httponlyset = true  //HttpOnly flag was set by the extension
								if (!flags.cancel)
									flags.toBeSecured = true;
							}							
						} 						
						if (this.statsOn && !flags.trash) //Add the cookie to statistics only if it is not trashed.
							statsUdpateCookies ( {name: cookie.name, domain: cookie.domain, path: cookie.path, 
								value: cookie.value, secure: orgsecure, httponly: orghttponly,    //Flag values before extension change them
								securesetext: secureset, httpsetext: httponlyset, session: issession, reverted: false}, response);
									
						/*Upgrade the cookie store, synchronously, in order to prevent situations in which the event of
						cookie store upgrade is fired after the event of a subsequent HTTP request. */
						var type = null;
						if (matchingCookie === null && !flags.cancel)
							type = INSERT;
						else if (matchingCookie !== null) {
							type = flags.cancel ? DELETE : UPDATE;
						}
						if (type === null)
							flags.trash = true;
						else {								
							if (matchingCookie !== null)
								this.removeCookie(cookie);
							if (!flags.cancel)
								this.addCookie(cookie); //Add the cookie to the store 'cookies'								
							/*Cookie received over HTTPS, not Secure, it does not over-write a cookie received over HTTPS, and
							 at least one flag is set by the extension, add it to secured cookies. It is initially by default not 
							 reverted. */
							if (flags.toBeSecured) { //A cookie is added to 'securedCookies' if at least a flag was set by the extension 
								this.addSecuredCookie({id: ++this.lastSecuredId, name: cookie.name,
									domain: cookie.domain, path: cookie.path, securesetext: secureset, httpsetext: httponlyset, reverted: false}, true);
							}
							this.addSyncUpdate(cookie, type);
						}
					}					
				}
			}
			/*Remove the cookie from the headers if marked to be trashed. */
			if (flags.trash) {
				debug("Trashing cookie {0} set by URL {1}".format(responseHeaders[i].value, url.toString()), DEBUG_COOKIES);
				responseHeaders.splice(i--, 1);
			}
		}
	return responseHeaders;
};

/*Check if the given cookie has been marked as HttpOnly by the extension. The parameter is a cookie object. */
CookiesStore.prototype.isHttpSetExtCookie = function (cookie) {
	var index = getCookieBaseDomain(cookie.domain);
	if (!this.securedCookies.hasOwnProperty(index))
		return false;
	for (var i = 0; i < this.securedCookies[index].length; i++)
		if (cookieMatch(cookie, this.securedCookies[index][i]))
			return this.securedCookies[index][i].httpsetext; 
	return false;
};

/*For statistic purposes. Returns 'id' of the secured cookie stored in memory 'securedCookies' */
CookiesStore.prototype.idSecuredCookie = function (cookie) {
	var index = getCookieBaseDomain(cookie.domain);
	if (!this.securedCookies.hasOwnProperty(index))
		return -1;
	for (var i = 0; i < this.securedCookies[index].length; i++)
		if (cookieMatch(cookie, this.securedCookies[index][i])) {
			return this.securedCookies[index][i].id;
			//console.log("idSecuredCookie: " + JSONstringify(this.securedCookies[index][i]));
		}
	return -1;
};

/*For statistic purposes. */
CookiesStore.prototype.removeSecuredCookieDb = function (cookie){
	var id = this.idSecuredCookie (cookie);  //Get the 'id' of the cookie
	if (id !== -1)
		secCookiesDb.remove(id,   //Remove the cookie from the secured cookies database
			function (result){	//onscuccess
				if(result !== false)
					console.log("Secured cookie '" + cookie.name + "' deleted successfully!");
			}, 
			function(error){  //onerror
				console.log("Secure cookie deletion failed!: " + error);
			});
};


/*Revert the 'Secure' flag of a cookie in Chrome store. */
CookiesStore.prototype.revertCookieInStore = function (cookie) {
	var url = "http" + (cookie.secure ? "s" : "") + "://" + cookie.domain + cookie.path;
    chrome.cookies.remove({"url": url, "name": cookie.name});
    chrome.cookies.set({"url": url, "name": cookie.name, "value": cookie.value, "path": cookie.path,
            "httpOnly": cookie.httpOnly, "secure": false});

};


/*Revert the 'HttpOnly' flag of a cookie in Chrome store. */
CookiesStore.prototype.revertHttpOnlyCookieInStore = function (cookie) {
	var url = "http" + (cookie.secure ? "s" : "") + "://" + cookie.domain + cookie.path;
    chrome.cookies.remove({"url": url, "name": cookie.name});
    chrome.cookies.set({"url": url, "name": cookie.name, "value": cookie.value, "path": cookie.path,
            "httpOnly": false, "secure": cookie.secure});

};

/*Revert all the cookies for a site, listed as white by the user. The HttpOnly flags of all the 
cookies set by extension are reverted, as they need to be accessed by JavaScript for functionality 
reasons (e.g., chat in gmail).*/
CookiesStore.prototype.revertHttpOnlyCookies = function (request) {
	var url = URI(request.url);
	var baseDomain = getUrlBaseDomain(url);
	if (this.cookies.hasOwnProperty(baseDomain)) { //If there is at least a cookie registered for domain in the Chrome store
		for (var i = 0; i < this.cookies[baseDomain].length; i++) {
			var cookie = this.cookies[baseDomain][i]; //Get the ith cookie for the domain 
			
			/*Check if the cookie may be attached to the request based on the domain-match and path-match rule */
			var c1 = domainMatch(cookie.domain, url.hostname()) && pathMatch(cookie.path, url.path());
			
			var ishttpsetext = this.isHttpSetExtCookie (cookie);
			var issecuresetext = this.isSecuredCookie(cookie);
			
			/*Any cookie set for a white site (for which user want NOT to set HttpOnly flags), is reverted 
			 (HttpOnly flag is made false if it was made true by the extension). */
			if (c1 && ishttpsetext) { 
				//this.removeSecuredCookieDb(cookie); //Remove it from secured cookies database  		
				this.removeCookie(cookie); //The cookie is removed from 'cookies' and 'securedCookies'.					
			    cookie.httpOnly = false; //Revert the HttpOnly flag only
				this.addCookie(cookie); //Add the cookie to the store 'cookies' - cookie is no more secured by the extension
				/*Change the 'httpsetext' flag to false (if HttpOnly flag is no more set by the extension) and keep reverted to 
				 false, as its Secure flag is not reverted in the 'securedCookies' */
				this.addSecuredCookie({id: ++this.lastSecuredId, name: cookie.name, domain: cookie.domain, path: cookie.path,
					securesetext: issecuresetext, httpsetext: false, reverted: false}, true);
				this.revertHttpOnlyCookieInStore(cookie);  //Revert the HttpOnly flag of the cookie in Chrome Store 
				//No need to update statistics as the corresponding cookies will be over-written by refreshing
				if (this.statsOn)
					statsUdpateCookies ( {name: cookie.name, domain: cookie.domain, path: cookie.path, 
						value: cookie.value, secure: !issecuresetext, httponly: false,   //Flags after extension flag/revert them
						securesetext: issecuresetext, httpsetext: false, session: true, reverted: false}, request);  //Last argument is to revert
			}
		}
	}
};


/*Revert the Secure flag of all the cookies for a URL that have been made Secure by the extension.
 This function must be called after fall-back to HTTP is detected, e.g. server redirect in 'handleRedirect'
 and in 'handleErrors' when the extension has to fall-back. (NOTE: this latter case may be exploited by the 
 attacker to stop requests over HTTPS making the CookiExt security measures ineffective, hence 
 requested is not downgraded to HTTP and cookies are not reverted when network errors are received).
 After reverting the corresponding 'secured' cookies, a general 'selectCookies' function may be used 
 without extending the cookie header with the cookies that were not secure but made secured by the 
 extension, as they will be reverted automatically by this function whenever needed. */
CookiesStore.prototype.revertCookies = function (request) {
	var url = URI(request.url).protocol(HTTP);
	var baseDomain = getUrlBaseDomain(url);
	if (this.cookies.hasOwnProperty(baseDomain)) { //If there is at least a cookie registered for domain in the Chrome store
		for (var i = 0; i < this.cookies[baseDomain].length; i++) {
			var cookie = this.cookies[baseDomain][i]; //Get the ith cookie for the domain 
			
			/*Check if the cookie may be attached to the request based on the domain-match and path-match rule */
			var c1 = domainMatch(cookie.domain, url.hostname()) && pathMatch(cookie.path, url.path());
			
			//The session cookie is not originally Secure and was secured by the extension. 
			var	c2 = cookie.secure && this.isSecuredCookie(cookie);
			
			//Any cookie that may be included with white-listed URL, is reverted (Secure flag is made false).
			if (c1 && c2) { 
				//this.removeSecuredCookieDb(cookie); // Remove it from secured cookies database  		
				this.removeCookie(cookie); //The cookie is removed from 'cookies' and 'securedCookies'.					
			    cookie.secure = false; //Revert the Secure flag only.
				this.addCookie(cookie); //Add the cookie to the store 'cookies' - cookie is no more secured by the extension
				/*Change the 'securesetext' flag to false (the Secure flag is no more set by the extension) and set reverted to 
				 true in the 'securedCookies'. */
				var ishttpsetext = this.isHttpSetExtCookie (cookie);
				this.addSecuredCookie({id: ++this.lastSecuredId, name: cookie.name, domain: cookie.domain, path: cookie.path,
					securesetext: false, httpsetext: ishttpsetext, reverted: true}, true);
				this.revertCookieInStore(cookie);  //Revert the Secure flag of the cookie in Chrome Store - needed for statistics
				//console.log("Cookeis reverted: " + cookie.name);
				if (this.statsOn)
					statsUdpateCookies ( {name: cookie.name, domain: cookie.domain, path: cookie.path, 
						value: cookie.value, secure: false, httponly: !ishttpsetext,   //Flag values after extension flag/revert them
						securesetext: false, httpsetext: ishttpsetext, session: true, reverted: true}, request);  //Last argument is to revert
			}
		}
	}
};

/*Update values for minimum length for session cookies and threshold for randomness. */
CookiesStore.prototype.setParameters = function (minLength, randThreshold) {
	debug("Minimum length: {0}, Randomness threshold: {1}".format(minLength, randThreshold), DEBUG_PREFERENCES);
	this.minLength = minLength;
	this.randThreshold = randThreshold;
};
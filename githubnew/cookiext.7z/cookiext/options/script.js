/* Delete the password when the corresponding button is clicked. */
function deletePassword() {
	var idx = parseInt($(this).attr("id").substr(2));
	if (!isNaN(idx)) {
		extension.loginsManager.removePassword(passwords[idx].password, passwords[idx].page, passwords[idx].action);
		$("tr[id='pwd{0}']".format(idx)).remove();
	}
}

/* Delete all passwords when the button is clicked. */
function deleteAllPasswords() {
	extension.loginsManager.removeAllPasswords();
	$("#passwords tfoot tr").remove();
}

/* Delete all redirects when the button is clicked. */
function deleteAllRedirects() {
	extension.redirectsManager.removeAllRedirects();
	$("#redirects tfoot tr").remove();
}

extension = chrome.extension.getBackgroundPage().extension;
$(document).ready(function () {
	/* Fill all fields with current preferences values. */
	var preferences = extension.preferencesManager.getAllPreferences();
	for (var pref in preferences)
		$("#" + pref).val(preferences[pref]);
	/* Register listener on update button. */
	$("#update").click(function () {
		var updatedSettings = $(".settingsField").map(function () {
			return {name: $(this).attr("id"), value: $(this).val()};
		}).get();
		extension.preferencesManager.updatePreferences(updatedSettings);
	});
	/* Print all passwords stored by the login manager with the buttons used
	to manage them. */
	passwords = extension.loginsManager.getPasswords();
	$.each(passwords, function (idx, entry) {
		var row = $("<tr>").attr("id", "pwd{0}".format(idx));
		row.append($("<td>").append(entry.page));
		row.append($("<td>").append(entry.action));
		var deleteButton = $("<button>").attr("id", "dp{0}".format(idx)).append("Delete");
		deleteButton.bind("click", deletePassword);
		row.append($("<td>").append(deleteButton));
		$("#passwords tfoot").append(row);
	});
	var deleteAllPassButton = $("<button>").append("Delete all passwords");
	deleteAllPassButton.bind("click", deleteAllPasswords);
	$("#passwords").append(deleteAllPassButton);
	/* Print all redirects stored by the redirects manager with the buttons used
	to manage them. */
	redirects = extension.redirectsManager.getRedirects();
	$.each(redirects, function (idx, entry) {
		if (entry.userRedirect) {
			var row = $("<tr>").attr("id", "ur{0}".format(idx));
			row.append($("<td>").append(entry.domain));
			row.append($("<td>").append("User redirect"));
			$("#redirects tfoot").append(row);
		}
		if (entry.autoRedirectPages) {
			var row = $("<tr>").attr("id", "ar{0}".format(idx));
			row.append($("<td>").append(entry.domain));
			row.append($("<td>").append("Automatic redirect for pages"));
			$("#redirects tfoot").append(row);
		}
		if (entry.autoRedirectResources) {
			var row = $("<tr>").attr("id", "as{0}".format(idx));
			row.append($("<td>").append(entry.domain));
			row.append($("<td>").append("Automatic redirect for resources"));
			$("#redirects tfoot").append(row);
		}
		for (var i = 0; i < entry.whitelistPages.length; i++) {
			var row = $("<tr>").attr("id", "wl{0}_{1}".format(idx, i));	
			row.append($("<td>").append(entry.whitelistPages[i]));
			row.append($("<td>").append("Whitelist"));
			$("#redirects tfoot").append(row);
		}
	});
	var deleteAllRedrButton = $("<button>").append("Delete all redirects");
	deleteAllRedrButton.bind("click", deleteAllRedirects);
	$("#redirects").append(deleteAllRedrButton);
});
// Includes code which is:
// Copyright (c) 2012 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

var enableClear = true;

//A reference to the background page
var bg = chrome.extension.getBackgroundPage();

//Needed for retrocompatibility with older versions of Chrome
if (!chrome.cookies) {
  chrome.cookies = chrome.experimental.cookies;
}

//Compares cookies for "key" (name, domain, etc.) equality, but not "value" equality.
function cookieMatch(c1, c2) {
  return (c1.name == c2.name) && (c1.domain == c2.domain) &&
         (c1.hostOnly == c2.hostOnly) && (c1.path == c2.path) &&
         (c1.secure == c2.secure) && (c1.httpOnly == c2.httpOnly) &&
         (c1.session == c2.session) && (c1.storeId == c2.storeId);
}

//Returns an array of sorted keys from an associative array.
function sortedKeys(array) {
  var keys = [];
  for (var i in array) {
    keys.push(i);
  }
  keys.sort();
  return keys;
}

//Shorthand for document.querySelector.
function select(selector) {
  return document.querySelector(selector);
}

//An object used for caching data about the browser's cookies, which we update
//as notifications come in.
function CookieCache() {
  this.cookies_ = {};

  this.reset = function() {
    this.cookies_ = {};
  }

  this.add = function(cookie) {
    var domain = cookie.domain;
    if (!this.cookies_[domain]) {
      this.cookies_[domain] = [];
    }
    this.cookies_[domain].push(cookie);
  };

  this.remove = function(cookie) {
    var domain = cookie.domain;
    if (this.cookies_[domain]) {
      var i = 0;
      while (i < this.cookies_[domain].length) {
        if (cookieMatch(this.cookies_[domain][i], cookie)) {
          this.cookies_[domain].splice(i, 1);
        } else {
          i++;
        }
      }
      if (this.cookies_[domain].length == 0) {
        delete this.cookies_[domain];
      }
    }
  };

  //Returns a sorted list of cookie domains that match |filter|. If |filter| is
  //null, returns all domains.
  this.getDomains = function(filter) {
    var result = [];
    sortedKeys(this.cookies_).forEach(function(domain) {
      if (!filter || domain.indexOf(filter) != -1) {
        result.push(domain);
      }
    });
    return result;
  }

  this.getCookies = function(domain) {
    return this.cookies_[domain].sort(function(a, b) {
        var x = a.name; var y = b.name;
        return ((x < y) ? -1 : ((x > y) ? 1 : 0));
    });
  };
}

var cache = new CookieCache();

function removeAllForFilter() {
  var filter = select("#src_url").value;
  cache.getDomains(filter).forEach(function(domain) {
    removeCookiesForDomain(domain);
  });
}

function removeAll() {
  var all_cookies = [];
  cache.getDomains().forEach(function(domain) {
    cache.getCookies(domain).forEach(function(cookie) {
      all_cookies.push(cookie);
    });
  });
  cache.reset();
  var count = all_cookies.length;
  for (var i = 0; i < count; i++) {
    removeCookie(all_cookies[i]);
  }
  chrome.cookies.getAll({}, function(cookies) {
    for (var i in cookies) {
      cache.add(cookies[i]);
      removeCookie(cookies[i]);
    }
  });
}

function removeCookie(cookie) {
  var url = "http" + (cookie.secure ? "s" : "") + "://" + cookie.domain +
            cookie.path;
  chrome.cookies.remove({"url": url, "name": cookie.name});
}

function removeCookiesForDomain(domain) {
  cache.getCookies(domain).forEach(function(cookie) {
    removeCookie(cookie);
  });
}

function resetTable(id) {
  var table = select(id);
  while (table.rows.length > 1) {
    table.deleteRow(table.rows.length - 1);
  }
}

var reload_scheduled = false;

function scheduleReloadCookieTable() {
  if (!reload_scheduled) {
    reload_scheduled = true;
    //setTimeout(getAllCookies, 250);
  }
}

function focusFilter() {
  select("#src_url").focus();
}

function resetFilter() {
  var filter = select("#src_url");
  filter.focus();
  if (filter.value.length > 0) {
    filter.value = "";
    //getAllCookies();
  }
}

var ESCAPE_KEY = 27;
window.onkeydown = function(event) {
  if (event.keyCode == ESCAPE_KEY) {
    resetFilter();
  }
}

//Keeps track of changes to the cookie store and reloads the extension page
function listener(info) {
  if (info.removed) {
    cache.remove(info.cookie);
  }
  else {
    cache.add(info.cookie);
  }
  //getAllCookies();
  scheduleReloadCookieTable();
}

function startListening() {
  chrome.cookies.onChanged.addListener(listener);
}

//Prints the list of rewritings
function showRewritings () {
  var table = select('#rewritings');
  resetTable("#rewritings");
  bg.rewritings.forEach (function (host) {
    var entries = host.split(",");
    var row = table.insertRow(-1);
    row.insertCell(-1).innerText = entries[0];
    row.insertCell(-1).innerText = entries[1];
	
    //A button to delete the rewriting
    var button = document.createElement("button");
    button.innerText = "delete";
    button.onclick = (function(src,dst,r){
        return function() {
          chrome.extension.sendMessage ({"del_src":src,"del_dst":dst});
          r.parentNode.removeChild(r);
        };
      }(entries[0],entries[1],row));
    var cell = row.insertCell(-1);
    cell.appendChild(button);
    cell.setAttribute("class", "button");  
  });
}

//Initial rendering of the extension page (and cache population)
function onload() {
  focusFilter();
  chrome.cookies.getAll({}, function(cookies) {
    startListening();
    for (var i in cookies) {
      cache.add(cookies[i]);
    }
    //getAllCookies();
  });
  showRewritings(); // For the time, we are not adding re-writings to the debug mode of extension
}

//Add an item to the rewriting list
function addRewrite () {
  var src = select("#src_url").value;
  var dst = select("#dst_url").value;
  chrome.extension.sendMessage({"src":src,"dst":dst});
  //setTimeout (showRewritings(), 150);
}

//Tracks any change to the local storages (e.g., re-writing hosts)
chrome.storage.onChanged.addListener(function(changes, namespace) {
  bg.rewritings = [];
  chrome.storage.local.get("rewritings", function (items) {
    if(items["rewritings"]) {
      bg.rewritings = items["rewritings"].split(";"); //populate 'rewritings' variable for immediate use
	  setTimeout (showRewritings(), 150);
    }
  });  
});

// Sets the security flags for session cookies
// If strong is true, then both HTTP-Only and Secure are set, otherwise just HTTP-Only
// Currently unused: this was once registered over a button (if restored, handle rewriting)
function setSecure(strong) {
  var filter = select("#src_url").value;
  var domains = cache.getDomains(filter);
  domains.forEach (function (domain) {
    var cookies = cache.getCookies(domain);
    cookies.forEach (function (cookie) {
      if (bg.statIsSessCookie(cookie) == true) {
        var url = "http" + (cookie.secure ? "s" : "") + "://" + cookie.domain + cookie.path;
        chrome.cookies.remove({"url": url, "name": cookie.name});
        var secflag;
        if (strong) {
          secflag = true;
        }
        else {
          secflag = cookie.secure;
        }
        chrome.cookies.set({"url": url, "name": cookie.name, "value": cookie.value, 
          "httpOnly": true, "secure": secflag});
      }
    });
  });
  //setTimeout(getAllCookies, 150);
}

//Deletes the session cookies registered by the domains matching the filter
//Helpful to validate the accuracy of the heuristic
function deleteSession() {
	var clearOn = confirm("You are about to delete all the session cookies. Please" + "\n" + 
							"click OK to proceed, otherwise click Cancel."); // Gets user choice true if 'OK' or false if 'Cancel'
	if (clearOn) {
		var filter = select("#src_url").value;
		var domains = cache.getDomains(filter);
		domains.forEach (function (domain) {
			var cookies = cache.getCookies(domain);
			cookies.forEach (function (cookie) {
			if (bg.statIsSessCookie(cookie) == true) {
				var url = "http" + (cookie.secure ? "s" : "") + "://" + cookie.domain + cookie.path;
				chrome.cookies.remove({"url": url, "name": cookie.name});
				/*Replace the cookie with a defaul session cookie value. It is not completely deleted so that actual deleted cookies
				by the server can be counted, while the value is a just a default value, so by replace the actual values, we can check
				if the deletion of session cookies would close the session. */
				//chrome.cookies.set({"url": url, "name": cookie.name, "value": "default-cGDiUks6pTExs8sX2seLhNzZ", "path": cookie.path});
			}
			});
		});
	}
	//alert("Sessions are cleared!");
	//setTimeout(getAllCookies, 150);  
}

//Prints all cookies
function getAllCookies() {
  reload_scheduled = false;
  var filter = select("#src_url").value;
  var domains = cache.getDomains(filter);
  var table = select('#results');
  resetTable("#results");
  domains.forEach (function (domain) {
    var cookies = cache.getCookies(domain);
    cookies.forEach (function (cookie) {
      //Prints the cookie information
      var row = table.insertRow(-1);
      row.insertCell(-1).innerText = domain;
      row.insertCell(-1).innerText = cookie.name;   
      row.insertCell(-1).innerText = cookie.value;  
      row.insertCell(-1).innerText = cookie.httpOnly;
      row.insertCell(-1).innerText = cookie.secure;
      row.insertCell(-1).innerText = bg.statIsSessCookie(cookie);               

      //A button to toggle the httpOnly flag
      var button = document.createElement("button");
      button.innerText = "http-only";
      button.onclick = (function(r){
        return function() {
          var url = "http" + (cookie.secure ? "s" : "") + "://" + cookie.domain + cookie.path;
          chrome.cookies.remove({"url": url, "name": cookie.name});
          chrome.cookies.set({"url": url, "name": cookie.name, "value": cookie.value, "path": cookie.path,
            "httpOnly": !cookie.httpOnly, "secure": cookie.secure});
          if (r.cells[3].innerText == "true") {r.cells[3].innerText = "false";} else {r.cells[3].innerText = "true";}
          //alert("Set cookie " + cookie.name + " for " + cookie.domain + " to HTTP-Only");
        };
      }(row));
      var cell = row.insertCell(-1);
      cell.appendChild(button);
      cell.setAttribute("class", "button");

      //A button to toggle the Secure flag
      var button = document.createElement("button");
      button.innerText = "secure";
      button.onclick = (function(r) {
        return function() {
          var url = "http" + (cookie.secure ? "s" : "") + "://" + cookie.domain + cookie.path;
          chrome.cookies.remove({"url": url, "name": cookie.name});
          chrome.cookies.set({"url": url, "name": cookie.name, "value": cookie.value, "path": cookie.path,
            "httpOnly": cookie.httpOnly, "secure": !cookie.secure});
          if (r.cells[4].innerText == "true") {r.cells[4].innerText = "false";} else {r.cells[4].innerText = "true";} 
          //alert("Set cookie " + cookie.name + " for " + cookie.domain + " to Secure");
        };
      }(row));
      var cell = row.insertCell(-1);
      cell.appendChild(button);
      cell.setAttribute("class", "button");

      //A button to delete the cookie
      var button = document.createElement("button");
      button.innerText = "Del";
      button.onclick = (function(r) {
        return function() {
          var url = "http" + (cookie.secure ? "s" : "") + "://" + cookie.domain + cookie.path;
          chrome.cookies.remove({"url": url, "name": cookie.name});
          r.parentNode.removeChild(r);
          //alert("Deleted cookie " + cookie.name + " for " + cookie.domain);
        };
      }(row));
      var cell = row.insertCell(-1);
      cell.appendChild(button);
      cell.setAttribute("class", "button");
    });
  });
}

 var isSecuredCookie = function (cookie, receivedcookies) {
	if (!receivedcookies)
		return false;
	for (var i = 0; i < receivedcookies.length; i++)
		if (bg.cookieMatch(cookie, receivedcookies[i])) {
			//console.log("manager:  Secured cookie: " + JSON.stringify(receivedcookies[i]));
			return receivedcookies[i].securesetext;
		}
		
	return false;
};


/*Compare two objects by value of 'nsecureext' (number of cookies secured) */
function sortBySecured(a,b) {
	if (a.nsecureext < b.nsecureext)
		return -1;
	if (a.nsecureext > b.nsecureext)
		return 1;
	return 0;
}


/*Compare two objects by value of 'nhttpsetext' (number of cookies with HttpOnly flag set) */
function sortByHttpOnly(a,b) {
	if (a.nhttpsetext < b.nhttpsetext)
		return -1;
	if (a.nhttpsetext > b.nhttpsetext)
		return 1;
	return 0;
}

/*Compare two objects by value of cookies secured per total number of sessions) */
function sortByPercSecured(a,b) {
	if ( ((a.nsessions == 0 ? 0: ((100 * a.nsecureext)/a.nsessions))) < ((b.nsessions == 0 ? 0: ((100 * b.nsecureext)/b.nsessions))))
		return -1;
	if ( ((a.nsessions == 0 ? 0: ((100 * a.nsecureext)/a.nsessions))) > ((b.nsessions == 0 ? 0: ((100 * b.nsecureext)/b.nsessions))))
		return 1;
		
	return 0;
}

/*Compare two objects by value of redirects supported per site) */
function sortredsupp(a,b) {
	if (a.redsupps < b.redsupps)
		return -1;
	if (a.redsupps > b.redsupps)
		return 1;
	return 0;
		
	return 0;
}

/*Converts float to integer (e.g. 3.9 => 3) */
function float2int (value) {
	return value | 0;
}
	
//Provides some statistics on session cookies
/* Collects statistics about redirects, cookies and secured cookies. A cookie which was not secured
  by the extension and was deleted by the server on sign out, is not counted in total. This does not
  affect our actual figures as the cookie was not secured by the extension at all. We observed, that
  a cookie which is Http-Only but not secured most probably is needed to in un-secured request. For
  example, cookie F and T set by Yahoo.com were Http-Only but not Secure. They were made Secure by
  the extension, but later on when the user clicks on other buttons such Finance, https is not 
  supported and hence the extension falls-back to http and the corresponding cookies (including
  F and T) are reverted back Http-Only.
*/
function stats () {
   var upgradedlinks =  (bg.redsupplinks ? bg.redsupplinks.length : 0) +  (bg.rednotsupplinks ? bg.rednotsupplinks.length : 0);
  var upgradedsublinks =  (bg.redsuppsublinks ? bg.redsuppsublinks.length : 0) +  (bg.rednotsuppsublinks ? bg.rednotsuppsublinks.length : 0);
  var swhitelistedpage = (bg.serverwhitelistpage ? bg.serverwhitelistpage.length : 0);
  var ewhitelistedpage = (bg.extwhitelistpage ? bg.extwhitelistpage.length : 0);
  var swhitelistedsub = (bg.serverwhitelistsub ? bg.serverwhitelistsub.length : 0);
  var ewhitelistedsub = (bg.extwhitelistsub ? bg.extwhitelistsub.length : 0);
  var whitelisted = swhitelistedpage + ewhitelistedpage + swhitelistedsub + ewhitelistedsub;
   
  var filter = select("#src_url").value;
  var domains = cache.getDomains(filter);
  var ncookies = 0;
  var nsessions = 0;
  
  var nreverted = 0;
  var ntopsecured = 0;
  var nsecureext = 0;
  var nhttpsetext = 0;  //count http flags set by extension 
 
  var nserverdel = 0;  // count session cookies deleted by servers upon sign-out
  var nhttponly = 0;
  var nsecure = 0;
  var ntop = 0;
  
  var nonsessh = 0;
  var nonsesss = 0;
  var nonsesst = 0;
  
  console.clear();
    
/*	
	bg.logedinsites = bg.logedsites; //update loged in sites from the collected ones.
	
    // Update the redirects storage from collected data.
	for (i=0; i< bg.sredpages.length; i++)
		bg.updateRedirectPages(bg.sredpages[i], true);
		
	for (i=0; i< bg.nsredpages.length; i++)
		bg.updateRedirectPages(bg.nsredpages[i], false);
		
	for (i=0; i< bg.sredsub.length; i++)
		bg.updateRedirectSub(bg.sredsub[i], true);
	
	for (i=0; i< bg.nsredsub.length; i++)
		bg.updateRedirectSub(bg.nsredsub[i], false);
	
	var reqpages = [];
	for (i=0; i<bg.reqpages.length; i++) 
		reqpages = bg.addRequestPages (reqpages, bg.reqpages[i]);
	bg.requestpages = reqpages;
	
   */
	 	
	var domredsupps = [];  
	for (i=0; i<bg.redsupplinks.length; i++) {
		var basedom = bg.getUrlBaseDomain(bg.URI(bg.redsupplinks[i]));
		domredsupps[basedom] = (!domredsupps[basedom] ?  1 : domredsupps[basedom] + 1);  
	}
	
	var domrednotsupps = [];  
	for (i=0; i<bg.rednotsupplinks.length; i++) {
		var basedom = bg.getUrlBaseDomain(bg.URI(bg.rednotsupplinks[i]));
		domrednotsupps[basedom] = (!domrednotsupps[basedom] ?  1 : domrednotsupps[basedom] + 1);  
	}
	
	var domredsubsupps = [];  
	for (i=0; i<bg.redsuppsublinks.length; i++) {
		var basedom = bg.getUrlBaseDomain(bg.URI(bg.redsuppsublinks[i]));
		domredsubsupps[basedom] = (!domredsubsupps[basedom] ?  1 : domredsubsupps[basedom] + 1);  
	}
	
	var domredsubnotsupps = [];  
	for (i=0; i<bg.rednotsuppsublinks.length; i++) {
		var basedom = bg.getUrlBaseDomain(bg.URI(bg.rednotsuppsublinks[i]));
		domredsubnotsupps[basedom] = (!domredsubnotsupps[basedom] ?  1 : domredsubnotsupps[basedom] + 1);  
	}
	
	/*
	var redpersites = []; 
	for (i = 0; i < bg.logedinsites.length; i++) {
		var site = bg.logedinsites[i];
		var redsupps = (!domredsupps[site] ? 0 : domredsupps[site]);
		var rednotsupps = (!domrednotsupps[site] ? 0 : domrednotsupps[site]);
		var redsubsupps = (!domredsubsupps[site] ? 0 : domredsubsupps[site]);
		var redsubnotsupps = (!domredsubnotsupps[site] ? 0 : domredsubnotsupps[site]);
		
		var redobj = {site: site, redsupps: redsupps, rednotsupps: rednotsupps, 
					 redsubsupps: redsubsupps, redsubnotsupps: redsubnotsupps};
		redpersites.push(redobj);
	}
		
	if (!redpersites.length < 1) {
		console.log("Redirects per site: ");
		redpersites.sort(sortredsupp);
		for (i=0; i<redpersites.length; i++) {
			console.log(JSON.stringify(redpersites[i]));
		} 
	}
		
	//domredsupps: , domrednotsupps: , domredsubsupps: , domredsubnotsupps: , 
  
	var cookieentries = bg.collectedcookies.split("##");	
	
	// This block store each cookie only once in 'mycookies' store, if there are more
	//than one occurrences of a cookie in 'collectedcookies'. 
	
	var response = {tabId: 1, type: 'main_frame'};
	for(var i=0; i < cookieentries.length; i++){
		var cookieObj = bg.parseCookieStr(cookieentries[i]);
		bg.statsUdpateCookies (cookieObj, response);
	} 
	*/
			
	// List of object: each stores site (base domain) name, total number of cookies, sessions, 
	//Http-Only and Secure flags set by extension for that site.
	var statspersite = []; 	
    		
		
		var receivedcookies =  bg.mycookies; //cookieentries; //in 'StatisticsCookies', cookie information, which can analysed when needed
	    var lengthcookies = receivedcookies.length;
		
		for (var i = 0; i < lengthcookies; i++) {			
			var seccookie = bg.parseCookieStr(receivedcookies[i]);
			var ckbasedomain = bg.getCookieBaseDomain(seccookie.domain);
			
			// Check the base domain of the cookie in the list of sites where we have personal account.
			//Cookies from other sites are ignored in statistics. Currently, we are checking only in the list 
			//of sites where the user has loged in. For better results, it can be replaced with a list of
			//sites where the user has created personal accounts. 
			var islogedin = bg.isSiteInLogedIn(ckbasedomain);  //bg.statsIsInVisitedSites(ckbasedomain); //
			
			//Ignore all cookies from sites we did not signed-in during statistics collection. This will
			//ignore cookies set by third party request (e.g. clicking a link to xyz.com at page abc.com where
			//the user is loged-in). 
			if (islogedin) {  				
				ncookies++;
				var issession = seccookie.session; //checkSess ({name: seccookie.name, value: seccookie.value}); 
				var securesetext = seccookie.securesetext;
				var httpsetext = seccookie.httpsetext;
				var httponly = seccookie.httponly;
				var secure = seccookie.secure;
				var reverted = seccookie.reverted;
						
				//Current status (in 'mycookies', which may include cookies deleted (on sign-out) and/or reverted. 
				if (!issession){
					if (secure && httponly)
						nonsesst++;
					else if (httponly)
						nonsessh++;
						else if (secure)
							nonsesss++;			
				} // If the cookie was reverted by the extension and it is non-secure. It may not exist in Chrome store as it
				//may have been deleted by the server on sign out. 	
				else {  //Session cookies
					nsessions++;
					//Count session cookies by flags 
					if(secure && httponly) // If both flags were originally set (not set by the extension)
						ntop++;
					else if (secure)  // If the Secure flag was originally set
							nsecure++;
						else if (httponly)  // If the HttpOnly flag was originally set
							nhttponly++;
					
					if (reverted) 
						nreverted++;  
					if (securesetext && httpsetext)
						ntopsecured++;	// Both Secure and Http-Only were secured by the extension
					else if (securesetext)
							nsecureext++;  // Only Secure flag set by the extension 
						else if (httpsetext)
							nhttpsetext++; // Only Http-Only flag set by the extension 
				}
						
				var found = false;
				//Check if the session cookie is still in Chrome store (it may have been deleted by the server when user loged out).
				var temcookies; 
				if (issession) {  
					domains.forEach(function(domain) {
						var cookies = cache.getCookies(domain);
						temcookies = cookies;
						cookies.forEach(function(c) {
							if (bg.cookieMatch(c, seccookie))
								found = true;   // Server has not deleted the secured cookie
							});
					});
			
					if (!found) { // If the server has deleted the cookie from the store 
						nserverdel++;
					}	
				}			
				
				//Add the statistics to each domain 
				//var ckbasedomain = bg.getCookieBaseDomain(seccookie.domain);
				var nsitecookies; 
				var nsitesessions;
				var nsitesecureext;
				var nsitehttpsetext;
				
				if (!statspersite[ckbasedomain])
					statspersite [ckbasedomain] = 
						{site: ckbasedomain, ncookies: 0, nsessions: 0, nhttpsetext: 0, nsecureext: 0,
							redsupps: 0, rednotsupps: 0, redsubsupps: 0, redsubnotsupps: 0};
			
				var sitestats = statspersite [ckbasedomain];
			
				nsitecookies = sitestats.ncookies + 1;
				nsitesessions = (issession ? sitestats.nsessions + 1 : sitestats.nsessions);
				nsitesecureext = (securesetext ? sitestats.nsecureext + 1 : sitestats.nsecureext);			
				nsitehttpsetext = (httpsetext ? sitestats.nhttpsetext + 1 : sitestats.nhttpsetext);
			
				var redsupps = (!domredsupps[ckbasedomain] ? 0 : domredsupps[ckbasedomain]);
				var rednotsupps = (!domrednotsupps[ckbasedomain] ? 0 : domrednotsupps[ckbasedomain]);
				var redsubsupps = (!domredsubsupps[ckbasedomain] ? 0 : domredsubsupps[ckbasedomain]);
				var redsubnotsupps = (!domredsubnotsupps[ckbasedomain] ? 0 : domredsubnotsupps[ckbasedomain]);
							 
				var updatedstats = { site: ckbasedomain, ncookies: nsitecookies, nsessions: nsitesessions,
									nsecureext: nsitesecureext, nhttpsetext: nsitehttpsetext, 
									redsupps: redsupps, rednotsupps: rednotsupps, 
									redsubsupps: redsubsupps, redsubnotsupps: redsubnotsupps};	
									
				statspersite [ckbasedomain] = updatedstats;	
				
			}
		}
		
  var statistics = 
  "- Statistics - " + "\n\n"
  //Session cookies
  + "Session cookies: " + nsessions + " (out of " + ncookies + " cookies)" + "\n"
    + "\t Original status: \n"
	+ "\t - Http-Only and Secure: " + ntop + "\n" 
	+ "\t - Http-Only (but not Secure): " + nhttponly + "\n"
	+ "\t - Secure (but not Http-Only): " + nsecure + "\n"
	+ "\t - Without flags: " + (nsessions - ntop - nhttponly - nsecure) + "\n\n" 
	
    + "\t Secured/reverted by the extension: \n"
	+ "\t - Secured (Secure and Http-Only): " + ntopsecured + "\n"
	+ "\t - Secured (Secure): " + nsecureext + "\n"
	+ "\t - Secured (Http-Only): " + nhttpsetext + "\n"
	// The following include Http-Only cookies set by extension or originally set but not secure now, even they were
	+ "\t - Reverted: " + nreverted + "\n\n" 
	
	//Deleted on sign-out
	+ "\t - Sessions deleted by the server: " + nserverdel + "\n\n"
	
	//Non-session cookies
  + "Non-session cookies with flags: " + (nonsesst + nonsessh + nonsesss) + "\n" 
	+ "\t - Http-Only and Secure: " + nonsesst + "\n" 
	+ "\t - Http-Only (but not Secure): " + nonsessh + "\n"
	+ "\t - Secure (but not Http-Only): " + nonsesss + "\n"
	+ "\t - Without flags: " + (ncookies - nsessions - (nonsesst + nonsessh + nonsesss)) + "\n\n" 
  	
  + "Total requests: " + (bg.requestpages.length + bg.requestsubs) + " ( " + bg.requestpages.length 
		+ " pages, " + bg.requestsubs + " sub-resources )" + "\n\n"
	
  //Main frame requests
  + "Redirected main frame requests: " +  upgradedlinks + " ( out of " + bg.requestpages.length + ")" + "\n"
  + "\t - Redirected supported requests: " + (bg.redsupplinks ? bg.redsupplinks.length : 0) + "\n"
  + "\t - Redirected not supported requests: " + (bg.rednotsupplinks ? bg.rednotsupplinks.length : 0) + "\n\n"
  //Sub-resource requests
  + "Redirected sub-resource requests: " +  upgradedsublinks + " ( out of " + bg.requestsubs + ")" + "\n"
  + "\t - Redirected supported requests: " + (bg.redsuppsublinks ? bg.redsuppsublinks.length : 0) + "\n"
  + "\t - Redirected not supported requests: " + (bg.rednotsuppsublinks ? bg.rednotsuppsublinks.length : 0) + "\n\n" 
  //White listed requests
  + "White listed requests: " + whitelisted + "\n"
  + "\t - extension white listed request pages: " + ewhitelistedpage + "\n"
  + "\t - extension white listed request resources: " + ewhitelistedsub + "\n"
  + "\t - Server white listed request pages: " + swhitelistedpage + "\n"  
  + "\t - Server white listed request resources: " + swhitelistedsub
  ; 
  
 
	console.log(statistics);
 
    console.log("\n White listed (for HttpOnly) sites: " + bg.whitesites.length);
	for (i = 0; i < bg.whitesites.length; i++)
		console.log("\"" + bg.whitesites[i] + "\",");
		
    console.log("\nStatistics per site: ");
	for(var d in statspersite)
		console.log(JSON.stringify(statspersite[d]) + ",");
	
   /*
   //Collecting urls users have visited is a violation of privacy, so we only keep statistics in numbers.
   var printUrl = function(url) {
		if (bg.validUrl(url))
			console.log("\"" + url + "\",");
  
	};	
	
	console.log("\n White listed (for HttpOnly) sites: " + bg.whitesites.length);
	for (i = 0; i < bg.whitesites.length; i++)
		console.log("\"" + bg.whitesites[i] + "\",");
		
	console.log("\n Loged-in sites: " + bg.logedinsites.length);
	for (i = 0; i < bg.logedinsites.length; i++)
		console.log("\"" + bg.logedinsites[i] + "\",");
	
	//console.log("\n Sub-resource requests: " + bg.requestsubs);
	
    console.log("\n Supported redirects pages: ");
	for (i = 0; i < bg.redsupplinks.length; i++)
		//console.log("\"" + bg.redsupplinks[i] + "\",");
		printUrl(bg.redsupplinks[i]);
		
	console.log("\n Non-supported redirects pages: ");
	for (i = 0; i < bg.rednotsupplinks.length; i++)
		printUrl(bg.rednotsupplinks[i]);
					
	console.log("\n" + " Cookies: ");
	for (i = 0; i < bg.mycookies.length; i++)
		console.log(bg.mycookies[i] + "##\\");
		
	console.log("\n Page requests: ");
	for (i=0; i<bg.requestpages.length; i++)
		printUrl(bg.requestpages[i]);
	
	console.log("\n Supported redirects resources: ");
	for (i = 0; i < bg.redsuppsublinks.length; i++)
		printUrl(bg.redsuppsublinks[i]);
		
	console.log("\n Non-supported redirects resources: ");
	for (i = 0; i < bg.rednotsuppsublinks.length; i++)
		printUrl(bg.rednotsuppsublinks[i]);	
	*/
	
    alert("Statistics printed. To see the results, please open the 'console': \n"
	      + " Right-click in white space -> Inspect element -> Console");
} // End of stats()


//Exports complete information about the cookies
function exportCookies () {
	var filter = select("#src_url").value;
	var domains = cache.getDomains(filter);
	var output = "";

	domains.forEach (function (domain) {
		var cookies = cache.getCookies(domain);
		cookies.forEach(function(cookie) {
			output = output + JSON.stringify(cookie) + "\n";
		});
	});
	console.log("Exporting cookies:\n" + output);
}
	  
var onsuccess = function(){
  console.log('The statistics, secured cookies and auto-redirects are cleared!'); 
  console.clear();
};

var onerror = function(error){
  console.log('Oh some error occurred in clearing the statistics!', error);
};

clearStats = function (){
var clearOn = confirm("You are about to delete all the statistics. Please" + "\n" + 
						"click OK to proceed, otherwise click Cancel."); // Gets user choice true if 'OK' or false if 'Cancel'
 if (clearOn){
	// Clear statistics in memory
	bg.redsupplinks = "";
	bg.redsuppsublinks = "";
	bg.rednotsupplinks = "";		
	bg.rednotsuppsublinks = "";
	bg.whitelist = "";
	bg.serverwhitelistpage = "";
	bg.serverwhitelistsub = "";
	bg.extwhitelistpage = "";
	bg.extwhitelistsub = "";
	bg.requestpages = ""; 
	bg.requestsubs = 0;
	bg.logedinsites = "";
	bg.whitesites = "";
	
	// Clear statistics in storage
	chrome.storage.local.set({"redsupplinks": ""});
	chrome.storage.local.set({"redsuppsublinks": ""});
	chrome.storage.local.set({"rednotsupplinks": ""});
	chrome.storage.local.set({"rednotsuppsublinks": ""});
	chrome.storage.local.set({"serverwhitelistpage": ""});
	chrome.storage.local.set({"serverwhitelistsub": ""});
	chrome.storage.local.set({"extwhitelistpage": ""});
	chrome.storage.local.set({"extwhitelistsub": ""});
	chrome.storage.local.set({"requestpages": ""});
	chrome.storage.local.set({"requestsubs": ""});
	chrome.storage.local.set({"logedinsites": ""});
	chrome.storage.local.set({"whitesites": ""});
	
	// Clear redirect (non-statistics) database
	bg.redirDb.clear();
	bg.mycookies = [];
	chrome.storage.local.set({"mycookies": ""});
	bg.secCookiesDb.clear(onsuccess, onerror);
 } 
 
};
	
document.addEventListener('DOMContentLoaded', function() {
	onload();
	
   // document.querySelector('#secure_button').addEventListener('click', function () { setSecure(false); });
   // document.querySelector('#strong_secure_button').addEventListener('click', function () { setSecure(true); });
 
  //For statistics/debugging purposes - un-comment the correspond code in 'managaer.html'
   /*
	document.querySelector('#show_cookies').addEventListener('click', function(){
		alert("Cookies: " + bg.origcookies) }); 
	document.querySelector('#clear_cookies').addEventListener('click', function(){
		bg.origcookies = [];
		chrome.storage.local.set({"origcookies": ""});
		
	});	*/
  		
	/*
	document.querySelector('#show_supported').addEventListener('click', function(){
		//alert("Upgraded sub-resource links: " + bg.upgradsublinks.length);
		alert("Supported: " + bg.redsupplinks.length + 
	   ", Not supported: " + bg.rednotsupplinks.length + ", Supported links: " + bg.redsupplinks);
    });  
	
	document.querySelector('#clear_supported').addEventListener('click', function(){
		//chrome.extension.sendMessage({"clear":"notorsuported"}); 
		bg.redsupplinks = "";
		bg.rednotsupplinks = "";
		chrome.storage.local.set({"redsupplinks": ""});
		chrome.storage.local.set({"rednotsupplinks": ""});
	});   
   
   document.querySelector('#clear_stats').addEventListener('click',  clearStats); 
   
   */
       
   /*
	document.querySelector('#clear_wlist').addEventListener('click', function(){
		bg.whitelist = [];
		chrome.storage.local.set({"whitelist": ""});
    });
	
	document.querySelector('#show_wlist').addEventListener('click', function(){
        alert("Server page white-list: " + bg.serverwhitelistpage + "\n"
			+ "Extension page white-list: " + bg.extwhitelistpage );  	   
	  });
   */
	  	
	/*document.querySelector('#statistics').addEventListener('click', stats);
	document.querySelector('#remove_button').addEventListener('click', function () {
		removeAllForFilter();
		resetFilter();
		clearStats();
		//alert("All cookies and statistics are cleared!");
	}); 
	
	document.querySelector('#src_url_div input').addEventListener(
      'input', getAllCookies);
	document.querySelector('#src_url_div button').addEventListener(
      'click', resetFilter);
	*/ 
	
	document.querySelector('#add_rewrite').addEventListener('click', addRewrite);
	
	
	document.querySelector('#clear_rewrite').addEventListener('click', function () { 
		bg.rewritings = "";
		chrome.storage.local.set({"rewritings": ""});
		setTimeout (showRewritings, 150); 
	});
	
	/*	
	document.querySelector('#debug').addEventListener('click', function () {
		bg.ifdebug = !bg.ifdebug;
		alert("Debug mode set to: " + bg.ifdebug);
	});
	document.querySelector('#toggle').addEventListener('click', function () {
		bg.isOn = !bg.isOn;
		alert("Extension set to: " + bg.isOn);
	});
	
	document.querySelector('#export').addEventListener('click',exportCookies);	
	*/
	
	//document.querySelector('#delete_sess').addEventListener('click', deleteSession);		
});

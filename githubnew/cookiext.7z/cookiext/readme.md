
****INSTALLATION****



The extension can be installed by using the option "Load unpacked extension"
from the "Extensions" page
 inside Google Chrome and choose the folder where
source code of the CookiExt is stored.



****USING COOKIEXT****

If the enxtension is installed successfully, a new tab for custom redirections
should open. Open websites in tabs as usual. If a web application is not
properly working (e.g., chat is not activated, or login fails), click the
extension icon in the right top corner of the corresponding window to add
the website to whitelist for HttpOnly cookies and refresh the page. The extension
does not set the HttpOnly flag of session cookies from such websites. 



/* Get all login forms in the page. */
function getLoginForms() {
	return $("form").filter(function () {
		return $("input[type='password']", this).length >= 1;
	}).clone().map(function () {
		var fields = $(this).find("input, select, textarea").clone().map(function () {
			if ($(this).attr("type") === "hidden")
				return $(this);
			if ($(this).attr("type") === "submit")
				return $("<tr>").append([$("<td>"), $("<td>").append($(this).removeAttr("disabled"))]);
			if ($(this).attr("id") === undefined)
				$(this).attr("id", $(this).attr("name"));
			var label = $("label[for='{0}']".format($(this).attr("id")));
			return $("<tr>").append(
				[$("<td>").append($("<label>").attr("id", $(this).attr("id")).html(label.length === 0 ? $(this).attr("id") : label.text())), $("<td>").append($(this))]
			);
		}).get();
		$(this).empty().append($("<table>").append(fields));
		if ($("input[type='submit']", this).length === 0)
			return $(this).append($("<input>").attr("type", "submit")).prop("outerHTML");
		return $(this).append($("input[type='submit']", $(this))).prop("outerHTML");
	}).get();
}

/* If login forms are found in the page, clone them in order to be used in a popup action page. */
var loginForms = getLoginForms();
//console.log("Total forms: " + loginForms.length);

/*Added: Returns the value of a key e.g. for 'name="login_form"', it returns 'login_form'. */
function getFormHeaderElementValue(formheader, key){
	
	var keyidx = formHeader.indexOf(key);	
	var valueEnd = 0; 
	var nameValue = "";
	if(keyidx !== -1) {
		for(var i = keyidx + key.length + 1; i <= formHeader.length; i++){
			if(formHeader[i] === '"'){
			valueEnd = i;
			break;
			}
		}
		nameValue = formHeader.substring(keyidx + key.length + 1, valueEnd);
	}	
	return nameValue;
}

 
if (loginForms.length > 0) {
	/*Added: Gets the name and id of the form */
    var formHeader = loginForms[0].substring(0, loginForms[0].indexOf('>') + 1);	
	var nameValue = getFormHeaderElementValue(formHeader, 'name=');
	var idValue = getFormHeaderElementValue(formHeader, 'id=');	
	var formHeaderElements = formHeader.split(" ");  
	
	console.log("name=" + nameValue);
	console.log("id=" + idValue);
		
	/* // the original form is not disabled. 
	chrome.runtime.sendMessage({type: LOGIN_FORMS, forms: loginForms, referer: window.location.href});
	$("form").filter(function () {
		return $("input[type='password']", this).length >= 1;
	}).each(function () {
		$("input[type='password'], *[type='submit']", this).attr("disabled", "disabled");
	});
	*/
}

/* Ask if there are messages that should be shown in the page. */
chrome.runtime.sendMessage({type: ASK_FOR_MESSAGES});

/* Listener for incoming messages. */
chrome.runtime.onMessage.addListener(
	function (message, sender, sendResponse) {
		/*Added: Tell extension that login form was not received in response to a login operation
		- means user successfully signed in */
		if (message.type === 'LOGIN-OPERATION'){
			//console.log("Content: message received: " + loginForms.length > 0);
			if (!loginForms.length > 0) // If no login form was received
			chrome.runtime.sendMessage({
					type: 'NO-LOGIN-FORM-RECEIVED',
					url: message.url
				});
		} else		    
		if (message.type === DISPLAY_REDIRECT_MESSAGE) {
			var answer = confirm(REDIRECT_TEXT_MESSAGE); // Gets user choice true if 'OK' or false if 'Cancel'
			if (answer)
				chrome.runtime.sendMessage({
					type: REDIRECT,
					url: window.location.href,
					blank: false
				});
		} else if (message.type === DISPLAY_INFO_MESSAGE) {
			var messageDiv = $("<div>").text(message.text);
			messageDiv.css({
				"position": "fixed",
				"bottom": "15px",
				"padding": "10px",
				"z-index": "9999",
				"min-width": "200px",
				"max-width": "500px",
				"background-color": "#000",
				"opacity": "0.85",
				"display": "none",
				"color": "#fff",
				"text-align": "center",
			});
			$("body").append(messageDiv);
			messageDiv.css({"left": ($(window).width() / 2) - (messageDiv.width() / 2)});
			messageDiv.fadeIn();
			setTimeout(function () {
				messageDiv.fadeOut();
			}, 5000);
		} else if (message.type === FALLBACK) {
		    /*Checks the url for a query. If there is no query, the current time is put as query (? followed by time), 
			 otherwise, the symbol & followed by current time is kept after the query. */
			var newUrl = (URI(message.url).query() !== "" ? "{0}&{1}" : "{0}?{1}").format(message.url, (new Date()).getTime());
			if (message.requestType === IMAGE) 
				/* $("img") is equivalent to document.getElementById("img"), accessing the "img" DOM objects.
			    Then gets (filters) the set of "img" elements, as JQuery objects, whose "src" url match 'message.url' 
				and sets their "src" attributes to the 'newUrl'
				 */
				$("img").filter(function () { return this.src === message.url; }).attr("src", newUrl);
			else if (message.requestType === STYLESHEET)
				$("link").filter(function () { return this.href === message.url }).attr("href", newUrl);
			else if (message.requestType === SCRIPT) {
				$("script").filter(function () { return this.src === message.url; }).remove();
				$("<script>").attr("src", newUrl).appendTo("head");
			} else if (message.requestType === FRAME)
				$("frame, iframe").filter(function () { return this.src === message.url; }).attr("src", newUrl);
		}
	}
);

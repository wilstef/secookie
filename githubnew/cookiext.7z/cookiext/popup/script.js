function sendEvent() {
	var form = $("form").filter(":visible").get(0);
	extension.eventsManager.addLogin({
		method: form.method.toUpperCase(),
		type: LOGIN_OPERATION,
		formAction: form.getAttribute("action"),
		openerTab: activeTab.id,
		referer: referer
	});
}

function show(message, choice) {
	$("#message").text(message);
	if (choice) {
		$("#yes").show();
		$("#no").show();
		$("#ok").hide();
	} else {
		$("#yes").hide();
		$("#no").hide();
		$("#ok").show();
	}
	$("#overlay").show();
}

function submitListener(e) {
	var passwords = $("input[type='password']", $(e.target)).map(function () {
		return this.value;
	}).get();
	checks = extension.loginsManager.checkLogin(passwords, URI(activeTab.url), URI(e.target.getAttribute("action")));
	if (!checks.labelsMatch) {
		e.preventDefault();
		show(CROSS_DOMAIN_AUTH, false);
	} else if (checks.newAction) {
		e.preventDefault();
		show(NEW_FORM_ACTION.format(e.target.getAttribute("action")), true);
	} else if (checks.rejectedPasswords.length !== 0) {
		e.preventDefault();
		show(PASSWORD_MISMATCH.format(e.target.getAttribute("action")), true);
	} else
		sendEvent();
}

extension = chrome.extension.getBackgroundPage().extension;

chrome.tabs.query({active: true, currentWindow: true}, function (tabs) {
   	
	activeTab = tabs[0];
	forms = extension.loginsManager.getForms(activeTab.id);
	referer = extension.loginsManager.getReferer(activeTab.id);
	$("#container").prepend(
		$("<select>").append(
			$.map(forms, function (form, i) {
				console.log(form.getAttribute("action"));
				var option = $("<option>").attr({
					id: i, value: form.getAttribute("action")
				});
				if (i === 0) option.attr("selected");
				option.html(form.getAttribute("action"));
				return option;
			})
		)
	);
	$("select").change(function () {
		$("form").filter(":visible").hide();
		$(forms[parseInt($(":selected", this).attr("id"))]).show();
	});
	$(forms).find("input [type='submit']").attr("disabled", "");
	$(forms).slice(1).hide();
	
	//console.log("Forms: " + $("input[type='password']"));
	 
	$(forms).bind("submit", submitListener);
	$("#forms").append(forms);
	$("#yes").click(function (e) {
		for (var i = 0; i < checks.rejectedPasswords.length; i++)
			extension.loginsManager.addNewPassword(checks.rejectedPasswords[i], URI(activeTab.url), 
				URI(checks.formAction));
		sendEvent();
		$(forms).unbind("submit", submitListener);
		$("form").filter(":visible").find("*[type='submit']").click();
	});
	$("#no, #ok").click(function (e) {
		$("#overlay").hide();
	})
});
/* Loads redirects and secured cookies from the local databases, cookies from the browser cookie store and all
open tabs. Creates the extension object with these parameters and add listeners using Chrome APIs for events we need
to track. */

/* IDBStore wrapper: A database wrapper, where one can store and retrieve JavaScript objects (unlike localStorage: a
  key-value store) without a query language. IDBwrapper will open the database, check if a store with the given 
  name exists and if not, it will create it using the above properties. The whole nature of IndexedDB is asynchronous.
  More details can be found here:
  http://jensarps.de/2011/11/25/working-with-idbwrapper-part-1/  */
  
 //Creates a new store 'redirDb' inside of the same IndexedDB
 redirDb = new IDBStore({ 
		dbVersion: 1,
		storeName: "redirects",
		keyPath: "id",
		onStoreReady: onRedirDbReady,
		onError: function (error) {
			debug("Failure on loading redirects DB: {0}".format(error), DEBUG_ERROR);
		}
	});

function onRedirDbReady() {
	redirDb.getAll(onLoadedRedirects, function (error) {
		debug("Failure on retrieving redirects from the DB: {0}".format(error), DEBUG_ERROR);
	});
}


function onLoadedRedirects(redirs) {
	redirects = redirs;
	//Creates a new store 'secCookiesDb' inside of the same IndexedDB
	secCookiesDb = new IDBStore({ 
		dbVersion: 1,
		storeName: "securedCookies",
		keyPath: "name",
		onStoreReady: onSecuredCookiesDbReady,
		onError: function (error) {
			debug("Failure on loading secured cookies DB: {0}".format(error), DEBUG_ERROR);
		}
	});
}

function onSecuredCookiesDbReady() {
	secCookiesDb.getAll(onLoadedSecuredCookies, function (error) {
		debug("Failure on retrieving secured cookies from the DB: {0}".format(error), DEBUG_ERROR);
	});
}

//When the secured cookies are read from the store
function onLoadedSecuredCookies(secCookies) {
	securedCookies = secCookies;
	
	chrome.cookies.getAll({}, function (cookies) {
		chrome.tabs.query({windowType: "normal"}, function (tabs) {
		
		    //Uncomment when statistics (debug mode) is used. 
			var statsOn = false; //confirm("CookiExt can be used either in debug or normal mode. " + "\n"
				  //+ "Do you want to open CookiExt in debug mode?"); // Gets user choice true if 'OK' or false if 'Cancel'
			
			//Initializes the 'Extension' object
			extension = new Extension(cookies, tabs, DEFAULT_PREFERENCES, redirDb, redirects,
				secCookiesDb, securedCookies, statsOn);
			
			extension.showManager();
			 
			/*Add listener for cookies modifications. */
			chrome.cookies.onChanged.addListener(
				function (changeInfo) {
					extension.onCookieChange(changeInfo);
				}
			);
			/* Add listeners for requests. */
			chrome.webRequest.onBeforeRequest.addListener(
				function (details) {
					if (details.type === PAGE)
						debug(JSON.stringify(details), DEBUG_REQUESTS);
					return extension.upgradeRequest(details); 
				}, {
					urls: ["http://*/*", "https://*/*"]
				}, ["blocking", "requestBody"]
			);
			chrome.webRequest.onBeforeSendHeaders.addListener(
				function (details) {
					if (details.type === PAGE)
						debug(JSON.stringify(details), DEBUG_REQUESTS);
					return extension.analyzeRequest(details);
				}, {
					urls: ["http://*/*", "https://*/*"]
				}, ["blocking", "requestHeaders"]
			);
			chrome.webRequest.onHeadersReceived.addListener(
				function (details) {
					if (details.type === PAGE)
						debug(JSON.stringify(details), DEBUG_REQUESTS);
					return extension.analyzeResponse(details);
				}, {
					urls: ["http://*/*", "https://*/*"]
				}, ["blocking", "responseHeaders"]
			);
			
			chrome.webRequest.onBeforeRedirect.addListener(
				function(details) { 
					extension.handleRedirect(details);				
				}, 
			{urls: ['https://*/*']});
			
			
			chrome.webRequest.onErrorOccurred.addListener(
				function (details) {
					extension.handleErrors(details);
				}, {
					urls: ["http://*/*", "https://*/*"]
				}
			);
			
			//When clicking on the cookie icon, create or focus on the extension tab
			chrome.browserAction.onClicked.addListener(function(tab) {
				if (!tab)
					return;
					
				var site = getUrlBaseDomain(URI(tab.url));
				if (validUrl(tab.url))
					var useragree = confirm("Do you want to add the site " 
						+ site + " to list of white-listed site? "); // Gets user choice true if 'OK' or false if 'Cancel'
				else {
					useragree = false;
					alert("The URL you want to white-list is invalid");
				}				
				if (useragree)
				    extension.addWhiteSites(tab.url, tab.id);
			});

			/*Add listener for tab events. */
			chrome.tabs.onRemoved.addListener(
				function (tabId, removeInfo) {
					extension.onClosingTab(tabId);
				}
			);
			
			/*Add listener for messages passing. */
			chrome.runtime.onMessage.addListener(
				function (message, sender, sendResponse) {
					extension.onMessageReceived(message, sender, sendResponse);
				}
			);
			
			/*Add listener to the omnibox. */
			chrome.omnibox.onInputEntered.addListener(
				function (text, disposition) {
					debug("Inserted on address bar: {0}".format(text), DEBUG_OMNIBOX);
					chrome.tabs.query({active: true, currentWindow: true}, function (tabs) {
						extension.onModifiedAddressBar(text, tabs[0].id);
					});
				}
			); 
		});
	});
}
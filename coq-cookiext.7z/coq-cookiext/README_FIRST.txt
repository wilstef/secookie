The Coq source code has been compiled with Coq version
8.3pl5 on Windows 8.

To compile the Coq script code, there are two ways to follow:

USING 'make':
 - on command prompt, enter to the folder having 
  Coq code 'coq-cookiext-security-ver-2'
 - use the command 'coq_makefile -o Makefile -no-install *.v'
   This will create a file 'Makefile' in the same folder.
 - C:\coq-cookiext>make CookiExtSecurity.vo 
   If it complains about the library, use 
   C:\coq-cookiext>make -coqlib C:\Coq\lib CookiExtSecurity.vo
   This will compile all the .v files in order automaticall.
   
To execute each individual file, use the following method. 

USING 'coqc':
 - copy the files coqc.exe, coqide.exe and coqtop.exe
   from Coq\bin to the folder coq-cookiext.
 - on command prompt, use the command 'coqc' to
   compile individual .v files and create .vo files as below:
   C:\coq-cookiext>coqc -coqlib C:\Coq\lib ACoqFile.v.
 - Compile the files in the following order:
   	GlobalOptions.v
	CaseTactics.v
	GeneralTactics.v
	Tactics.v
	Classes.v
	Datatypes.v
	Collections.v
	Automations.v
	Refs.v
	RefSets.v
	RefPairSets.v
	RefMaps.v
	RefCollections.v
	BrowserIO.v
	BrowserPolicy.v
	CookiExtPolicy.v
	CookiExtBasicLemmas.v
	CookiExtSecurity.v
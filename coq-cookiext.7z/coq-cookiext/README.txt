*** OVERVIEW ***
 CookiExt Soundness Proof
 
 This project consist of the formal proof (in Coq proof assistant) of
 our browser CookiExt. Our previous work 'coq-bro-model-ver-x' contains
 the security guarantees of protection mechanisms Secure and HttpOnly in modern 
 browsers using non-interference security policy protecting session cookies. 
 However, that does not include the proof of patched browser. We have patched 
 the browser with our extension CookiExt. We redirect http requests to https
 if the website is full supported and flag (update) cookie flags.
 In this work, we have proof of patched version of the browser (CookiExt). For
 more detail, read the draft enclosed. 

*** COMPILATION ***
The Coq source code has been compiled with Coq version 8.3pl5 on Windows 8.

To compile the Coq script code, there are two ways to follow:

USING 'make':
 - on command prompt, enter to the folder having 
  Coq code 'coq-cookiext-security-ver-2'
 - use the command 'coq_makefile -o Makefile -no-install *.v'
   This will create a file 'Makefile' in the same folder.
 - C:\coq-cookiext-security-ver-2>make BrowsrSRS.vo 
   If it complains about the library, use 
   C:\coq-cookiext-security-ver-2>make -coqlib C:\Coq\lib BrowsrSRS.vo
   This will compile all the .v files in order automaticall.
   
To execute each individual file, use the following method. 

USING 'coqc':
 - copy the files coqc.exe, coqide.exe and coqtop.exe
   from Coq\bin to the folder coq-cookiext-security-ver-2.
 - on command prompt, use the command 'coqc' to
   compile individual .v files and create .vo files as below:
   C:\coq-cookiext-security-ver-2>coqc -coqlib C:\Coq\lib ACoqFile.v.
 - Compile the files in the following order:
   	GlobalOptions.v
	CaseTactics.v
	GeneralTactics.v
	Tactics.v
	Classes.v
	Datatypes.v
	Collections.v
	Automation.v
	Refs.v
	RefSets.v
	RefPairSets.v
	RefMaps.v
	RefCollections.v
	BrowserIO.v
	BrowserPolicy.v
	CookiExtPolicy.v
	CookiExtBasicLemmas.v
	CookiExtSecurity.v

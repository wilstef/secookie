Paper on formal model of Verilog.

